require(ggplot2);   require(mvtnorm)
require(gridExtra); require(randomForest)
require(nnet)
require(clv) 
require(mvtnorm); require(fields); require(cluster)
require(topicmodels); require(corrplot);

####-------------------------------- Get&Split Data ------------------------------

# Clear workspace
rm(list=ls(all=TRUE))

data<-read.csv("/home/gal/Boaz/Shiny Visualization Tool/Data/Data.csv",header=TRUE, sep = ",")
t<-table(data$Type)
View(t)

drops <- c("Time","PatientID", "Type", "Tag")
Ichilov<-as.data.frame(data[ , !(names(data) %in% drops)])

params<-colnames(Ichilov)

for (i in 1:ncol(Ichilov)){
  suppressWarnings(Ichilov[,i]<-as.numeric(as.character(Ichilov[,i])))
}

#pairs(Ichilov[,-5])

# Split for train and test sets
set.seed(123)
train_size <- 0.75*nrow(Ichilov)
train_valid_ind  <- sample(seq_len(nrow(Ichilov)), size=train_size)
valid_size<-round(0.25*length(train_valid_ind))
valid_ind<-train_valid_ind[1:valid_size]
train_ind<-train_valid_ind[-valid_ind]

validation<- Ichilov[valid_ind, ]
validation_Tag<-data[valid_ind, "Tag"]

train <- Ichilov[train_ind, ]
train$Tag<-data[train_ind,"Tag"]

test  <- Ichilov[-train_valid_ind, ]
test$Tag  <- data[-train_valid_ind, "Tag"]

nrow(train[train$Tag==1,])
nrow(test[test$Tag==1,])

# Run CV-10 over the train set to set ntre
mtry.acc   <- matrix(0, 5, 4)
folds      <- sample(5, nrow(train), replace=T)
folds.prob <- as.numeric(table(folds)/length(folds))
len<-length(train)

for(fold in 1:5){
  # Train forests
  
  rf1 <- randomForest(x=train[folds!=fold,1:(len-1)], y=factor(train$Tag[folds!=fold]), ntree=50, mtry=1)
  rf2 <- randomForest(x=train[folds!=fold,1:(len-1)], y=factor(train$Tag[folds!=fold]), ntree=50, mtry=2)
  rf3 <- randomForest(x=train[folds!=fold,1:(len-1)], y=factor(train$Tag[folds!=fold]), ntree=50, mtry=3)
  rf4 <- randomForest(x=train[folds!=fold,1:(len-1)], y=factor(train$Tag[folds!=fold]), ntree=50, mtry=4)
  
  # Predict for test fold and compute error rates
  preds1 <- predict(rf1, newdata=train[folds==fold,1:(len-1)], type='response')
  mtry.acc[fold, 1] <- sum(preds1==train[folds==fold,len])/nrow(train[folds==fold,])
  preds2 <- predict(rf2, newdata=train[folds==fold,1:(len-1)], type='response')
  mtry.acc[fold, 2] <- sum(preds2==train[folds==fold,len])/nrow(train[folds==fold,])
  preds3 <- predict(rf3, newdata=train[folds==fold,1:(len-1)], type='response')
  mtry.acc[fold, 3] <- sum(preds3==train[folds==fold,len])/nrow(train[folds==fold,])
  preds4 <- predict(rf4, newdata=train[folds==fold,1:(len-1)], type='response')
  mtry.acc[fold, 4] <- sum(preds4==train[folds==fold,len])/nrow(train[folds==fold,])
}

apply(apply(mtry.acc, 2, function(x){x*folds.prob}),2,sum)

# Test performance
rf       <- randomForest(x=train[folds!=fold,1:(len-1)], y=factor(train$Tag[folds!=fold]), ntree=50, mtry=1)
rf.preds <- predict(rf, newdata=test)
rf.performance <- sum(rf.preds==test[,len])/nrow(test)

View(rf$err.rate)

# Neural networks - same pipeline
neurons.acc   <- matrix(0, 5, 5)
for(fold in 1:5){
  # Train forests
  nn1 <- nnet(class.ind(Tag)~., data=train[folds!=fold,], size=3, softmax=T)
  nn2 <- nnet(class.ind(Tag)~., data=train[folds!=fold,], size=6, softmax=T)
  nn3 <- nnet(class.ind(Tag)~., data=train[folds!=fold,], size=9, softmax=T)
  nn4 <- nnet(class.ind(Tag)~., data=train[folds!=fold,], size=12, softmax=T)
  nn5 <- nnet(class.ind(Tag)~., data=train[folds!=fold,], size=15, softmax=T)
  
  # Predict for test fold and compute error rates
  preds1 <- predict(nn1, newdata=train[folds==fold,1:(len-1)], type='class')
  neurons.acc[fold, 1] <- sum(preds1==train[folds==fold,len])/nrow(train[folds==fold,])
  preds2 <- predict(nn2, newdata=train[folds==fold,1:(len-1)], type='class')
  neurons.acc[fold, 2] <- sum(preds2==train[folds==fold,len])/nrow(train[folds==fold,])
  preds3 <- predict(nn3, newdata=train[folds==fold,1:(len-1)], type='class')
  neurons.acc[fold, 3] <- sum(preds3==train[folds==fold,len])/nrow(train[folds==fold,])
  preds4 <- predict(nn4, newdata=train[folds==fold,1:(len-1)], type='class')
  neurons.acc[fold, 4] <- sum(preds4==train[folds==fold,len])/nrow(train[folds==fold,])
  preds5 <- predict(nn5, newdata=train[folds==fold,1:(len-1)], type='class')
  neurons.acc[fold, 5] <- sum(preds4==train[folds==fold,len])/nrow(train[folds==fold,])
}

apply(apply(neurons.acc, 2, function(x){x*folds.prob}),2,sum)

# Test performance
nn       <- nnet(class.ind(Tag)~., data=train, size=9, softmax=T)
nn.preds <- predict(nn, newdata=test,'class')
nn.performance <- sum(nn.preds==test[,len])/nrow(test)





# Start Lab

#####------------------------- Kmeans -------------------------

# Let's start with some simple Kmeans stuff
?kmeans


#example--------------------------


len=length(train)
res<-kmeans(train[,1:len-1], 7)
table(train$Tag, res$cluster)

plot_ly(train, x = train$HR, y = train$ArtBPS,color=res$cluster, mode = "markers")
plot_ly(train, x = train$HR, y = train$ArtBPS,color=train$Tag, mode = "markers")

plot_ly(train, x = train$CVP, y = train$PAPD,color=res$cluster, mode = "markers")
plot_ly(train, x = train$CVP, y = train$PAPD,color=train$Tag, mode = "markers")


plot(train[c("HR", "ArtBPS")], col=res$cluster)
plot(train[c("HR", "ArtBPS")], col=train$Tag)

#elbow method:

set.seed(123)
# Compute and plot wss for k = 2 to k = 15
k.max <- 15 # Maximal number of clusters
wss <- sapply(1:k.max, function(k){kmeans(train[,len-1], k, nstart=5)$tot.withinss})

plot_ly(x = 1:k.max, y = wss, mode = "markers")

plot(1:k.max, wss,
     type="b", pch = 19, frame = FALSE, 
     xlab="Number of clusters K",
     ylab="Total within-clusters sum of squares")
abline(v = 4, lty =2)

#Average silhouette method
library(cluster)

k.max <- 15
sil <- rep(0, k.max)
# Compute the average silhouette width for 
# k = 2 to k = 15
for(i in 2:k.max){
  km.res <- kmeans(train[,len-1], centers = i, nstart = 5)
  ss <- silhouette(km.res$cluster, dist(train[,len-1]))
  sil[i] <- mean(ss[, 3])
}
# Plot the  average silhouette width
plot_ly(x = 1:k.max, y = sil, mode = "markers")

plot(1:k.max, sil, type = "b", pch = 19, 
     frame = FALSE, xlab = "Number of clusters k")
abline(v = which.max(sil), lty = 2)


#---------------------------------

## FINDING THE BEST K

# Define experiment parameters and variables
K <- 25; inter <- c(); outer <- c(); ratio <- c();

# Clustering loop over K
for(k in 2:K){
  clust_data  <- kmeans(scale(train[,1:len-1]), centers=k, iter.max=25, nstart=5)
  inter       <- c(inter,   clust_data$tot.withinss)
  outer       <- c(outer,   clust_data$betweenss)
  ratio       <- c(ratio,   clust_data$tot.withinss/clust_data$betweenss)
}

# Organize and visualize results
l       <- length(seq(2,K))
results <- data.frame(K=rep(seq(2,K),3), metrics=c(rep('inter', l), rep('outer', l),rep('ratio', l)),
                      value=c(inter, outer, 1000*ratio)) 
ggplot(results, aes(x=K, y=value, color=factor(metrics))) + geom_line() + geom_point()

# We can see that the metrics always improve as K increases, which is not a desirable property!!! 

# Which is the best K? Compare Dunn's index and Davies-Bouldin


dunn <- c(); DB <- c(); K <- 8
for(k in 2:K){
  clust_data    <- kmeans(scale(train[,1:len-1]), centers=k, iter.max=25, nstart=5)
  scatt_data    <- cls.scatt.data(scale(train[,1:len-1]), clust=clust_data$cluster, dist='euclidean')
  dunn          <- c(dunn, clv.Dunn(scatt_data, 'centroid', 'centroid'))
  DB            <- c(DB,   clv.Davies.Bouldin(scatt_data, 'centroid', 'centroid'))
}

clust_metrics <- data.frame(K = rep(seq(2,K,1),2), value = c(dunn, DB), metric = c(rep('Dunn',K-1), rep('DB',K-1)))
ggplot(clust_metrics, aes(x=K, y=value, color=factor(metric))) + geom_point() + geom_line()


####-------------------------- Kmedoids with 'my own' distance metric -------------------------

# Create a distance matrix based on squared exponential kernel family
data    <- train[,1:len-1]
simMat  <- Exp.cov(data, data, theta=2, p=1)
distMat <- 1 - simMat

dunn <- c(); DB <- c(); K <- 8
for(k in 2:K){
  clust_data    <- pam(distMat, k, diss=T)
  scatt_data    <- cls.scatt.data(data, clust=clust_data$clustering, dist='euclidean')
  dunn          <- c(dunn, clv.Dunn(scatt_data, 'centroid', 'centroid'))
  DB            <- c(DB,   clv.Davies.Bouldin(scatt_data, 'centroid', 'centroid'))
}

clust_metrics <- data.frame(K = rep(seq(2,K,1),2), value = c(dunn, DB), metric = c(rep('Dunn',K-1), rep('DB',K-1)))
ggplot(clust_metrics, aes(x=K, y=value, color=factor(metric))) + geom_point() + geom_line()


# Visualize for K=k

k          <- 3
clust_data <- pam(distMat, k, diss=T)
data$clust <- factor(clust_data$clustering)

# Visualize our cluster scheme
p1 <- ggplot(data, aes(x=Sepal.Length, y=Sepal.Width,  color=clust, size=10)) + geom_point() + guides(color=F, size=F) 
p2 <- ggplot(data, aes(x=Sepal.Length, y=Petal.Width,  color=clust, size=10)) + geom_point() + guides(color=F, size=F)
p3 <- ggplot(data, aes(x=Sepal.Length, y=Petal.Length, color=clust, size=10)) + geom_point() + guides(color=F, size=F)
p4 <- ggplot(data, aes(x=Sepal.Width,  y=Petal.Length, color=clust, size=10)) + geom_point() + guides(color=F, size=F)
p5 <- ggplot(data, aes(x=Sepal.Width,  y=Petal.Width,  color=clust, size=10)) + geom_point() + guides(color=F, size=F)
p6 <- ggplot(data, aes(x=Petal.Length, y=Petal.Width,  color=clust, size=10)) + geom_point() + guides(color=F, size=F)

grid.arrange(p1, p2, p3, p4, p5, p6, ncol=3)


####-------------------------- Principal Component Analysis (PCA) ------------------------- 

# Let's get some data for this first
summary(USArrests) # basic plot
corrplot::corrplot(cor(USArrests), method = "ellipse") # slightly fancier

# Prepare the data
USA1 <- USArrests[,-3] # We'll only look at the crimes, leave out the population level
USA1 <- scale(USA1)    # Scale the data (important for PCA as well)

# Run PCA on the data
pca1  <-  prcomp(USA1) # The main workhorse.
pca1$rotation # loadings
screeplot(pca1)

# Plot the first two PCs
pcs  <-  data.frame(pca1$x)
ggplot(data = pcs, aes(x = PC1, y = PC2, label = rownames(pcs))) +
  geom_hline(yintercept = 0, colour = "gray65") +
  geom_vline(xintercept = 0, colour = "gray65") +
  geom_text(colour = "red", alpha = 0.8, size = 6) +
  ggtitle("PCA plot of USA States - Crime Rates")

# Let's see how this might be applied to Iris

data(iris)
data <- iris[,-5]
corrplot::corrplot(cor(data), method = "ellipse")

data <- scale(data)
pca1 <-  prcomp(data) # The main workhorse.
pca1$rotation # loadings
screeplot(pca1)

pc_data <- data.frame(pca1$x[,1:2], species=iris$Species)
ggplot(data = pc_data, aes(x = PC1, y = PC2, color=species)) +
  geom_hline(yintercept = 0, colour = "gray65") +
  geom_vline(xintercept = 0, colour = "gray65") +
  geom_point(size=4) + 
  ggtitle("PCA plot of Iris Flowers")


####-------------------------- Latent Dirichlet Allocation  (LDA) ------------------------- 

# Load the associated press dataset
data('AssociatedPress', package='topicmodels')

# Train LDA model on data
lda     <- LDA(AssociatedPress[1:50,], control = list(alpha = 0.1), k = 10, method="Gibbs")

# Let's take a look at the type of things LDA learns
View(terms(lda, 10)) # Top 10 most fequent words for each topic in training set

# Top 3 most likely topics for each document in training set
View(topics(lda, 3))


# Infer posterior distributions for some training documents
lda_inf   <- posterior(lda, AssociatedPress[60:65,])
terms     <- lda_inf$terms

# Let's randomly sample some words, and look at the topic specific distribution
number    <- 1100
words2use <- sample(10473, number, replace=F)
terms     <- terms[,words2use]

term_data <- data.frame(terms=rep(colnames(terms),5), posterior=c(terms[1,],terms[2,],terms[3,],terms[4,],terms[5,]),
                        topic=factor(c(rep(1, number),rep(2, number),rep(3, number),rep(4, number),rep(5, number))))

p <- ggplot(term_data, aes(x=terms, y=posterior, fill=topic)) + geom_bar(stat='identity') + ylim(0,max(term_data$posterior+0.001)) +
  theme(axis.text.x = element_text(angle = 90, hjust = 1))

ggplotly(p)


