
library(e1071) 
require(gridExtra)
library("corrplot")
library("plotly")

Ichilov<-read.csv("/home/gal/Boaz/Shiny Visualization Tool/Data/Data.csv",header=TRUE, sep = ",")

drops <- c("Time","PatientID", "Tag", "Type")
Ichilov.matrix<-as.data.frame(Ichilov[ , !(names(Ichilov) %in% drops)])
data<-Ichilov

summary_matrix<-matrix(0,8,13)
colnames(summary_matrix)<-c(" ",names(Ichilov.matrix))

#######@@@@@@@@@@@@@------------------ Statistics ----------------------@@@@@@@@@@@@@#########

###---------------------------------------- Draw histograms for all vars -------------------------------------------------###

hist(data$PAPD, breaks=100, col="light blue", xlab="X", main="Value frequency of PAPD")
hist(data$CVP, breaks=50, col="green", xlab="X", main="Value frequency of CVP")
hist(data$ArtBPM, breaks=100, col="green", xlab="X", main="Value frequency of ArtBPM")
hist(data$ArtBPS, breaks=100, col="green", xlab="X", main="Value frequency of ArtBPS")
hist(data$HR, breaks=100, col="green", xlab="X", main="Value frequency of HR")
hist(data$RR_total, breaks=100, col="green", xlab="X", main="Value frequency of RR_total")
hist(data$RR_mandatory, breaks=100, col="green", xlab="X", main="Value frequency of RR_mandatory")
hist(data$Spo2, breaks=100, col="green", xlab="X", main="Value frequency of v1")
hist(data$ST1, breaks=100, col="green", xlab="X", main="Value frequency of v1")
hist(data$ST2, breaks=100, col="green", xlab="X", main="Value frequency of v1")
hist(data$ST3, breaks=100, col="green", xlab="X", main="Value frequency of v1")
hist(data$Fio2, breaks=100, col="green", xlab="X", main="Value frequency of v1")

# Draw histograms after log transformation (for some vars)
hist(log(data$CVP+60), breaks=50, col="green", xlab="X", main="Value frequency of log(CVP+60)")
hist(log(data$RR_total), breaks=100, col="green", xlab="X", main="Value frequency of log(RR_total)")
hist(log(data$Spo2), breaks=100, col="green", xlab="X", main="Value frequency of log(Spo2)")




summary_matrix[1,1]<-"Mean"
summary_matrix[2,1]<-"Median"
summary_matrix[3,1]<-"SD"
summary_matrix[4,1]<-"Skewness"
summary_matrix[5,1]<-"quantile 25%"
summary_matrix[6,1]<-"quantile 75%"
summary_matrix[7,1]<-"Number of observations"
summary_matrix[8,1]<-"Number of missing values"

  
summary_matrix[1,2:ncol(summary_matrix)]<-sapply(Ichilov.matrix,mean,na.rm=TRUE)
summary_matrix[2,2:ncol(summary_matrix)]<-sapply(Ichilov.matrix,median,na.rm=TRUE)
summary_matrix[3,2:ncol(summary_matrix)]<-sapply(Ichilov.matrix,sd,na.rm=TRUE)
summary_matrix[4,2:ncol(summary_matrix)]<-sapply(Ichilov.matrix,skewness,na.rm=TRUE)
summary_matrix[5,2:ncol(summary_matrix)]<-sapply(Ichilov.matrix,function(x) quantile(x,0.25,na.rm=T)) 
summary_matrix[6,2:ncol(summary_matrix)]<-sapply(Ichilov.matrix,function(x) quantile(x,0.75,na.rm=T)) 
summary_matrix[7,2:ncol(summary_matrix)]<-sapply(Ichilov.matrix,function(x) length(x)) 
summary_matrix[8,2:ncol(summary_matrix)]<-sapply(Ichilov.matrix,function(x) sum(is.na(x))) 



plot_ly(data = Ichilov, x = ~HR, y = ~Tag, color=Ichilov$Tag, marker = list(size = 10)) %>%
  layout(title = 'covariate - explainatory', yaxis = list(zeroline = FALSE), xaxis = list(zeroline = FALSE))
plot_ly(data = Ichilov, x = ~ArtBPS, y = ~Tag, color=Ichilov$Tag, marker = list(size = 10)) %>%
  layout(title = 'covariate - explainatory', yaxis = list(zeroline = FALSE), xaxis = list(zeroline = FALSE))
plot_ly(data = Ichilov, x = ~ArtBPM, y = ~Tag, color=Ichilov$Tag, marker = list(size = 10)) %>%
  layout(title = 'covariate - explainatory', yaxis = list(zeroline = FALSE), xaxis = list(zeroline = FALSE))
plot_ly(data = Ichilov, x = ~CVP, y = ~Tag, color=Ichilov$Tag, marker = list(size = 10)) %>%
  layout(title = 'covariate - explainatory', yaxis = list(zeroline = FALSE), xaxis = list(zeroline = FALSE))
plot_ly(data = Ichilov, x = ~PAPD, y = ~Tag, color=Ichilov$Tag, marker = list(size = 10)) %>%
  layout(title = 'covariate - explainatory', yaxis = list(zeroline = FALSE), xaxis = list(zeroline = FALSE))
plot_ly(data = Ichilov, x = ~RR_total, y = ~Tag, color=Ichilov$Tag, marker = list(size = 10)) %>%
  layout(title = 'covariate - explainatory', yaxis = list(zeroline = FALSE), xaxis = list(zeroline = FALSE))
plot_ly(data = Ichilov, x = ~RR_mandatory, y = ~Tag, color=Ichilov$Tag, marker = list(size = 10)) %>%
  layout(title = 'covariate - explainatory', yaxis = list(zeroline = FALSE), xaxis = list(zeroline = FALSE))
plot_ly(data = Ichilov, x = ~Spo2, y = ~Tag, color=Ichilov$Tag, marker = list(size = 10)) %>%
  layout(title = 'covariate - explainatory', yaxis = list(zeroline = FALSE), xaxis = list(zeroline = FALSE))
plot_ly(data = Ichilov, x = ~ST1, y = ~Tag, color=Ichilov$Tag, marker = list(size = 10)) %>%
  layout(title = 'covariate - explainatory', yaxis = list(zeroline = FALSE), xaxis = list(zeroline = FALSE))
plot_ly(data = Ichilov, x = ~ST2, y = ~Tag, color=Ichilov$Tag, marker = list(size = 10)) %>%
  layout(title = 'covariate - explainatory', yaxis = list(zeroline = FALSE), xaxis = list(zeroline = FALSE))
plot_ly(data = Ichilov, x = ~ST3, y = ~Tag, color=Ichilov$Tag, marker = list(size = 10)) %>%
  layout(title = 'covariate - explainatory', yaxis = list(zeroline = FALSE), xaxis = list(zeroline = FALSE))
plot_ly(data = Ichilov, x = ~Fio2, y = ~Tag, color=Ichilov$Tag, marker = list(size = 10)) %>%
  layout(title = 'covariate - explainatory', yaxis = list(zeroline = FALSE), xaxis = list(zeroline = FALSE))

frame()
grid.table(summary_matrix)

z <- cor(data,use="p")
#levelplot(z)
corrplot(z, method="color")

write.csv(summary_matrix, file="summary.csv")


###@@@@@@@@@@@@@--------------------- Draw Histograms with alarm frequencies ------------------@@@@@@@@@@@@@@@@@###

# RUN FUNCTIONS:

# ********************* draw Both Graphs Function *********************

drawGraphs <- function(varName, legendLocation)
{
  varNum <- grep(varName, colnames(data))
  
  par(mfrow=c(2,1), bg="white") # Space for 2 graphs
  
  # Stacked Bar Plot - Alarm by varName - Frequency
  counts <- table(data$Tag,  cut(data[,varNum],50))
  barplot(counts, main=(paste("Alarm by ", varName)),
          xlab=varName, col=c("cadetblue","firebrick"), ylab = "Frequency",
          legend = c("Not Alarm","Alarm"), args.legend = list(x = legendLocation))
  
  # Stacked Bar Plot - Alarm by varName - Proportion
  counts <- table(data$Tag,  cut(data[,varNum],50))
  countsProp   <- counts #Copy counts
  
  for (i in 1:ncol(counts))
  {
    sum = counts[1,i] + counts[2,i]
    
    if (sum != 0)
    {
      countsProp[1,i] = as.double(counts[1,i] / sum)
      countsProp[2,i] = as.double(counts[2,i] / sum)    
    }
  }
  
  barplot(countsProp,  
          xlab=varName, col=c("cadetblue","firebrick"), ylab = "Proportion",
          #        legend = rownames(counts),args.legend = list(x = "topleft",inset=c(0.9,0), xpd = TRUE))
  )
  
  par(mfrow=c(1,1), bg="white")
  
}


# ********************* draw Only Frequency Graph Function ********************* #

drawGraph_Frequency <- function(varName, legendLocation)
{
  varNum <- grep(varName, colnames(data))
  
  # Stacked Bar Plot - Alarm by varName
  counts <- table(data$Tag,  cut(data[,varNum],50))
  barplot(counts, main=(paste("Alarm by ", varName)),
          xlab=varName, col=c("cadetblue","firebrick"), ylab = "Frequency",
          legend = c("Not Alarm","Alarm"), args.legend = list(x = legendLocation))
}


# ********************* draw Only Proportion Function *********************#

drawGraph_Proportion <- function(varName, legendLocation)
{
  varNum <- grep(varName, colnames(data))
  
  counts <- table(data$Tag,  cut(data[,varNum],50))
  countsProp   <- counts #Copy counts
  
  for (i in 1:ncol(counts))
  {
    sum = counts[1,i] + counts[2,i]
    
    if (sum != 0)
    {
      countsProp[1,i] = as.double(counts[1,i] / sum)
      countsProp[2,i] = as.double(counts[2,i] / sum)    
    }
  }
  
  # Stacked Bar Plot - Alarm by varName
  barplot(countsProp,  
          xlab=varName, col=c("cadetblue","firebrick"), ylab = "Proportion",
          #        legend = rownames(counts),args.legend = list(x = "topleft",inset=c(0.9,0), xpd = TRUE))
  )
  
  par(mfrow=c(1,1), bg="white")
}

# ****************************** Functions end




# Draw graphs for all vars
drawGraphs("PAPD", "topright")
drawGraphs("CVP", "topright")
drawGraphs("ArtBPM", "topright")
drawGraphs("ArtBPS", "topleft")
drawGraphs("HR", "topleft")
drawGraphs("RR_total", "topright")
drawGraphs("RR_mandatory", "topright")
drawGraphs("Spo2", "topleft")
drawGraphs("ST1", "topleft")
drawGraphs("ST2", "topleft")
drawGraphs("ST3", "topleft")
drawGraphs("Fio2", "topright")

#If only one of the graphs is needed:
drawGraph_Frequency("ST1", "topleft")
drawGraph_Proportion("ST1", "topleft")







###@@@@@@@@@@@@@--------------------- All kinds of stuff ------------------@@@@@@@@@@@@@@@@@###

levels(factor(data$term)) #column different values

rowSums(is.na(data)) # Number of missing per row

colSums(is.na(data)) # Number of missing per column/variable

table(data$term) #column different values with amounts

length(unique(data$member_id)) #column number of unique values

data$termnew <- 0 #Add column

#Variable Frequency
hist(data$PAPD, breaks=100, col="green", xlab="X", main="Value frequency of v1")

#Variable Boxplot
boxplot(data[,1], horizontal=TRUE, main="v1")

#scatter plot - 2 variables
plot(data[,14],data[,15])

#scatter plot matrix
scatterMatrix <- pairs.panel(data[,3:15])

#covariance matrix
cov(data[,3:15])

#correlation matrix
correlation <- cor(data[,3:14])
corrplot <- corrplot(correlation)

rcorr(data[,3:14], type="pearson")
  