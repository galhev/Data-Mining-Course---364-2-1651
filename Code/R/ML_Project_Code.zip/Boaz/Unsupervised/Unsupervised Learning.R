# K means------------------------------------------------------
require(gridExtra)
library(caret)
library("e1071")

#Result tables-------------------------------------------------

resultsTable<-(as.data.frame(matrix(ncol=2,nrow=7)))
colnames(resultsTable)<-c(" ","k-means")

i<-1
resultsTable[1,i]<-"Number of\n False Alarms"
resultsTable[2,i]<-"Number of\n True Alarms"
resultsTable[3,i]<-"True\n positive"
resultsTable[4,i]<-"True\n negetive"
resultsTable[5,i]<-"True posivite\n + True negetive"
resultsTable[6,i]<-"Percentage of\n Totel True"
resultsTable[7,i]<-"Total\n Observations"

resultsTable2<-(as.data.frame(matrix(ncol=2,nrow=5)))
colnames(resultsTable2)<-c(" ","k-means")

resultsTable2[1,i]<-"Sensitivity (%)"
resultsTable2[2,i]<-"Specificity (%)"
resultsTable2[3,i]<-"PPV (%)"
resultsTable2[4,i]<-"NPV (%)"
resultsTable2[5,i]<-"Accuracy (%)"

#Functions-----------------------------------------------------

Model_Test_Measure <- function(preds, test.data.tags, doPrint, w1){
  set.seed(3588)
  #w1  #Sensitivity weight
  w2  <- 1   #Specificity weight - beta error weight
  
  c <- w2 / (w2+w1) # Specificity weight, Sensitivity weight is (1-c)
  b <- w1 #Sensitivity times weight vs. Precision
  
  conf <- confusionMatrix(data=preds, test.data.tags, positive="1")
  
  confMatrix <- conf$table
  
  resultsTable<-(as.data.frame(matrix(ncol=8,nrow=1)))
  #colnames(resultsTable)<-c("Accuracy","Sensitivity","Specificity", "Precision", "F1_score", "Fb_score","weightedAccuracy", "ParmetMeasure", "ParmetMeasureWeighted")
  colnames(resultsTable)<-c("Accuracy","Sensitivity","Specificity", "Precision", "F1_score", "Fb_score","Weighted_Accuracy", "Weighted_Measure")
  
  resultsTable$Accuracy <- round(unname(conf$overall["Accuracy"]), digits = 6)  
  resultsTable$Sensitivity <- round(unname(conf$byClass["Sensitivity"]), digits = 6)  # Also called Recall
  resultsTable$Specificity <- round(unname(conf$byClass["Specificity"]), digits = 6)
  resultsTable$Precision <- round(unname(conf$byClass["Precision"]), digits = 6)
  resultsTable$F1_score <- round(unname(conf$byClass["F1"]), digits = 6)
  resultsTable$Fb_score <- round(unname(( (1+(b^2)) * resultsTable$Precision * resultsTable$Sensitivity ) / ( (b^2) * resultsTable$Precision + resultsTable$Sensitivity )), digits = 6)
  resultsTable$Weighted_Accuracy <- round(unname((c*resultsTable$Specificity + (1-c)*resultsTable$Sensitivity)), digits = 6)
  #resultsTable$ParmetMeasure <- round(unname(sqrt(resultsTable$Sensitivity * resultsTable$Specificity)), digits = 6)
  #resultsTable$ParmetMeasureWeighted <- round(unname(  ((resultsTable$Sensitivity^w1) * (resultsTable$Specificity^w2))^(1/(w1+w2))  ), digits = 6)
  resultsTable$Weighted_Measure <- round(unname(  ((resultsTable$Sensitivity^w1) * (resultsTable$Specificity^w2))^(1/(w1+w2))  ), digits = 6)
  
  if(doPrint == TRUE)
  {
    #Print results:
    print("confusion Matrix:")
    print(confMatrix)
    print(resultsTable)
    
    frame()
    grid.table(resultsTable)
  }
  
  return(resultsTable)
}
#Check tags:
check.tags <- function(tag, reject){
  res<-NA
  if(!tag=="Na")
  { 
    if(reject==1 & tag==1)
    {res<-"TP"}
    if(reject==1 & tag==0)
    {res<-"FP"}
    if(reject==0 & tag==0)
    {res<-"TN"}
    if(reject==0 & tag==1)
    {res<-"FN"}
  }
  return(res)
}

ROC1 <- function(i, percent_match, mimic, resultsTable, resultsTable2){
  tags<-nrow(mimic)
  
  Total_True<-(sum(percent_match=="TP",na.rm=TRUE))+(sum(percent_match=="TN",na.rm=TRUE))
  resultsTable[1,i]<-(sum(mimic$tag==0))
  resultsTable[2,i]<-(sum(mimic$tag==1))
  resultsTable[3,i]<-(sum(percent_match=="TP",na.rm=TRUE))
  resultsTable[4,i]<-(sum(percent_match=="TN",na.rm=TRUE))
  resultsTable[5,i]<-Total_True
  resultsTable[6,i]<-round(Total_True/tags*100,3)
  resultsTable[7,i]<-tags
  
  return (resultsTable)
}


ROC2 <- function(i, percent_match, mimic, resultsTable, resultsTable2){
  
  Sensitivity<-(sum(percent_match=="TP",na.rm=TRUE))/((sum(percent_match=="TP",na.rm=TRUE))+(sum(percent_match=="FN",na.rm=TRUE))) 
  
  Specificity<-(sum(percent_match=="TN",na.rm=TRUE))/((sum(percent_match=="TN",na.rm=TRUE))+(sum(percent_match=="FP",na.rm=TRUE))) 
  
  PPV<-(sum(percent_match=="TP",na.rm=TRUE))/((sum(percent_match=="TP",na.rm=TRUE))+(sum(percent_match=="FP",na.rm=TRUE))) 
  
  NPV<-(sum(percent_match=="TN",na.rm=TRUE))/((sum(percent_match=="TN",na.rm=TRUE))+(sum(percent_match=="FN",na.rm=TRUE))) 
  
  Accuracy<-(sum(percent_match=="TN",na.rm=TRUE)+sum(percent_match=="TP",na.rm=TRUE))/((sum(percent_match=="TN",na.rm=TRUE))+sum(percent_match=="FN",na.rm=TRUE)+sum(percent_match=="TP",na.rm=TRUE)+sum(percent_match=="FP",na.rm=TRUE)) 
  
  resultsTable2[1,i]<-Sensitivity
  resultsTable2[2,i]<-Specificity
  resultsTable2[3,i]<-PPV
  resultsTable2[4,i]<-NPV
  resultsTable2[5,i]<-Accuracy
  
  return (resultsTable2)
}


#Algorithm---------------------------------------------------------------------------
Ichilov<-read.csv("/home/gal/Boaz/Shiny Visualization Tool/Data/Data.csv",header=TRUE, sep = ",")
drops <- c("Time","PatientID", "Tag", "Type")
data<-as.data.frame(Ichilov[ , !(names(Ichilov) %in% drops)])

periods<-nrow(data)
param.mean <- sapply(data,mean,na.rm = TRUE)
param.sd <- sapply(data,FUN =  sd)


normalData<-matrix(0,nrow(data),ncol(data))
for(i in 1:ncol(data)){
  normalData[,i]<-(data[,i]-param.mean[i])/param.sd[i]
}

# Let's start with some simple Kmeans stuff
k             <- 3
clust_data    <- kmeans(scale(normalData), centers=k, iter.max=25, nstart=5)
newData       <- data
newData$clust <- factor(clust_data$cluster)
newData$tag <- Ichilov$Tag

table(Ichilov$Tag, clust_data$cluster)

newData$cluster[newData$clust==1]<-0
newData$cluster[newData$clust==2]<-0
newData$cluster[newData$clust==3]<-1

  
percent.match.Kmeans<- rep(NA, length(newData$tag))

for(i in 1:nrow(newData))
{
  percent.match.Kmeans[i]<-check.tags(tag=newData$tag[i],reject=newData$cluster[i])
}

resultsTable<-ROC1(i=2, percent_match=percent.match.Kmeans, mimic=newData, resultsTable=resultsTable)
resultsTable2<-ROC2(i=2, percent_match=percent.match.Kmeans, mimic=newData,resultsTable2=resultsTable2)

frame()
grid.table(resultsTable2)

frame()
grid.table(resultsTable)

Model_Test_Measure(newData$cluster, newData$tag, TRUE, 10)

#FINDING THE BEST K---------------------
K <- 25; inter <- c(); outer <- c(); ratio <- c();

# Clustering loop over K
for(k in 2:K){
  clust_data  <- kmeans(scale(data), centers=k, iter.max=25, nstart=5)
  inter       <- c(inter,   clust_data$tot.withinss)
  outer       <- c(outer,   clust_data$betweenss)
  ratio       <- c(ratio,   clust_data$tot.withinss/clust_data$betweenss)
}

# Organize and visualize results
l       <- length(seq(2,K))
results <- data.frame(K=rep(seq(2,K),3), metrics=c(rep('inter', l), rep('outer', l),rep('ratio', l)),
                      value=c(inter, outer, 1000*ratio)) 
ggplot(results, aes(x=K, y=value, color=factor(metrics))) + geom_line() + geom_point()

library(clv)
library(clusterSim)
library(clValid)

dunn <- c(); DB <- c(); K <- 10
for(k in 2:K){
  clust_data    <- kmeans(scale(data), centers=2, iter.max=25, nstart=5)
  scatt_data    <- cls.scatt.data(scale(data), clust=clust_data$cluster, dist='euclidean')
  dunn          <- c(dunn, clv.Dunn(scatt_data, 'centroid', 'centroid'))
  DB            <- c(DB,   clv.Davies.Bouldin(scatt_data, 'centroid', 'centroid'))
}

clust_metrics <- data.frame(K = rep(seq(2,K,1),2), value = c(dunn, DB), metric = c(rep('Dunn',K-1), rep('DB',K-1)))
ggplot(clust_metrics, aes(x=K, y=value, color=factor(metric))) + geom_point() + geom_line()



