
library("pROC")
library("zoo")
library("pROC")
library("rms")
require(gridExtra)
library('qcc')
library('MASS')
library('ggplot2')
library('mvtnorm')
library("plyr")
library("plotly")
library('MASS')
library('mvtnorm')
library(caret)
library("e1071")

#Get&Split Data ------------------------------

# Clear workspace
rm(list=ls(all=TRUE))

Ichilov<-read.csv("/home/gal/Boaz/Shiny Visualization Tool/Data/Data.csv",header=TRUE, sep = ",")


Ichilov$cvpLog<-log(Ichilov$CVP+60)
Ichilov$RR_total_Log<-log(Ichilov$RR_total)
Ichilov$Spo2_Log<-log(Ichilov$Spo2)

drops <- c("Time","PatientID", "Tag", "Type")
p.matrix<-as.data.frame(Ichilov[ , !(names(Ichilov) %in% drops)])

params<-colnames(p.matrix)

for (i in 1:ncol(p.matrix)){
  suppressWarnings(p.matrix[,i]<-as.numeric(as.character(p.matrix[,i])))
}

drops <- c("CVP","RR_total", "Spo2")
Ichilov<-as.data.frame(Ichilov[ , !(names(Ichilov) %in% drops)])


Ichilov<-Ichilov[,c(1,2,3,4, 5, 6, 7, 8, 9, 10,11,14, 15, 16, 12, 13)]



# Split for train and test sets
set.seed(123)
drops <- c("Time","PatientID", "Tag", "Type", "ST2", "ST3", "ArtBPS")
p.matrix<-as.data.frame(Ichilov[ , !(names(Ichilov) %in% drops)])
params<-colnames(p.matrix)
for (i in 1:ncol(p.matrix)){
  suppressWarnings(p.matrix[,i]<-as.numeric(as.character(p.matrix[,i])))
}

train_size <- 0.75*nrow(p.matrix)
train_ind  <- sample(seq_len(nrow(p.matrix)), size=train_size)

train <- Ichilov[train_ind, ]
test  <- Ichilov[-train_ind, ]

train.matrix<-as.data.frame(train[ , !(names(train) %in% drops)])
test.matrix<-as.data.frame(test[ , !(names(test) %in% drops)])

nrow(train[train$Tag==1,])
nrow(test[test$Tag==1,])
nrow(Ichilov[Ichilov$Tag==0,])


#Result tables-------------------------------------------------------

resultsTable<-(as.data.frame(matrix(ncol=3,nrow=7)))
colnames(resultsTable)<-c(" ","Hotelling","Mass Univariate")

i<-1
resultsTable[1,i]<-"Number of\n False Alarms"
resultsTable[2,i]<-"Number of\n True Alarms"
resultsTable[3,i]<-"True\n positive"
resultsTable[4,i]<-"True\n negetive"
resultsTable[5,i]<-"True posivite\n + True negetive"
resultsTable[6,i]<-"Percentage of\n Totel True"
resultsTable[7,i]<-"Total\n Observations"

resultsTable2<-(as.data.frame(matrix(ncol=3,nrow=5)))
colnames(resultsTable2)<-c(" ","Hotelling","Mass Univariate")

resultsTable2[1,i]<-"Sensitivity (%)"
resultsTable2[2,i]<-"Specificity (%)"
resultsTable2[3,i]<-"PPV (%)"
resultsTable2[4,i]<-"NPV (%)"
resultsTable2[5,i]<-"Accuracy (%)"


#Functions:----------------------------------------------------------

Model_Test_Measure <- function(preds, test.data.tags, doPrint, w1){
  set.seed(3588)
  #w1  #Sensitivity weight
  w2  <- 1   #Specificity weight - beta error weight
  
  c <- w2 / (w2+w1) # Specificity weight, Sensitivity weight is (1-c)
  b <- w1 #Sensitivity times weight vs. Precision
  
  conf <- confusionMatrix(data=preds, test.data.tags, positive="1")
  
  confMatrix <- conf$table
  
  resultsTable<-(as.data.frame(matrix(ncol=8,nrow=1)))
  #colnames(resultsTable)<-c("Accuracy","Sensitivity","Specificity", "Precision", "F1_score", "Fb_score","weightedAccuracy", "ParmetMeasure", "ParmetMeasureWeighted")
  colnames(resultsTable)<-c("Accuracy","Sensitivity","Specificity", "Precision", "F1_score", "Fb_score","Weighted_Accuracy", "Weighted_Measure")
  
  resultsTable$Accuracy <- round(unname(conf$overall["Accuracy"]), digits = 6)  
  resultsTable$Sensitivity <- round(unname(conf$byClass["Sensitivity"]), digits = 6)  # Also called Recall
  resultsTable$Specificity <- round(unname(conf$byClass["Specificity"]), digits = 6)
  resultsTable$Precision <- round(unname(conf$byClass["Precision"]), digits = 6)
  resultsTable$F1_score <- round(unname(conf$byClass["F1"]), digits = 6)
  resultsTable$Fb_score <- round(unname(( (1+(b^2)) * resultsTable$Precision * resultsTable$Sensitivity ) / ( (b^2) * resultsTable$Precision + resultsTable$Sensitivity )), digits = 6)
  resultsTable$Weighted_Accuracy <- round(unname((c*resultsTable$Specificity + (1-c)*resultsTable$Sensitivity)), digits = 6)
  #resultsTable$ParmetMeasure <- round(unname(sqrt(resultsTable$Sensitivity * resultsTable$Specificity)), digits = 6)
  #resultsTable$ParmetMeasureWeighted <- round(unname(  ((resultsTable$Sensitivity^w1) * (resultsTable$Specificity^w2))^(1/(w1+w2))  ), digits = 6)
  resultsTable$Weighted_Measure <- round(unname(  ((resultsTable$Sensitivity^w1) * (resultsTable$Specificity^w2))^(1/(w1+w2))  ), digits = 6)
  
  if(doPrint == TRUE)
  {
    #Print results:
    print("confusion Matrix:")
    print(confMatrix)
    print(resultsTable)
    
    frame()
    grid.table(resultsTable)
  }
  
  return(resultsTable)
}

#Check tags:
check.tags <- function(tag, reject){
  res<-NA
  if(!tag=="Na")
  { 
    if(reject==1 & tag==1)
    {res<-"TP"}
    if(reject==1 & tag==0)
    {res<-"FP"}
    if(reject==0 & tag==0)
    {res<-"TN"}
    if(reject==0 & tag==1)
    {res<-"FN"}
  }
  return(res)
}

#Plot algorithem:
plot.algorithem <- function(data, ucl){
  plot(data,type="o",main = paste0("Control Chart: ",xlab = "sample number",ylab = "Statisti"))
  abline(h = ucl,  col = "red")
}

#resultsTable1

ROC1 <- function(i, percent_match, data, resultsTable, resultsTable2){
  tags<-(sum(data$Tag==0))+(sum(data$Tag==1))
  
  Total_True<-(sum(percent_match=="TP",na.rm=TRUE))+(sum(percent_match=="TN",na.rm=TRUE))
  resultsTable[1,i]<-(sum(data$Tag==0))
  resultsTable[2,i]<-(sum(data$Tag==1))
  resultsTable[3,i]<-(sum(percent_match=="TP",na.rm=TRUE))
  resultsTable[4,i]<-(sum(percent_match=="TN",na.rm=TRUE))
  resultsTable[5,i]<-Total_True
  resultsTable[6,i]<-round(Total_True/tags*100,3)
  resultsTable[7,i]<-tags
  
  return (resultsTable)
}


#resultsTable2

ROC2 <- function(i, percent_match, data, resultsTable, resultsTable2){
  
  Sensitivity<-(sum(percent_match=="TP",na.rm=TRUE))/((sum(percent_match=="TP",na.rm=TRUE))+(sum(percent_match=="FN",na.rm=TRUE))) 
  
  Specificity<-(sum(percent_match=="TN",na.rm=TRUE))/((sum(percent_match=="TN",na.rm=TRUE))+(sum(percent_match=="FP",na.rm=TRUE))) 
  
  PPV<-(sum(percent_match=="TP",na.rm=TRUE))/((sum(percent_match=="TP",na.rm=TRUE))+(sum(percent_match=="FP",na.rm=TRUE))) 
  
  NPV<-(sum(percent_match=="TN",na.rm=TRUE))/((sum(percent_match=="TN",na.rm=TRUE))+(sum(percent_match=="FN",na.rm=TRUE))) 
  
  Accuracy<-(sum(percent_match=="TN",na.rm=TRUE)+sum(percent_match=="TP",na.rm=TRUE))/((sum(percent_match=="TN",na.rm=TRUE))+sum(percent_match=="FN",na.rm=TRUE)+sum(percent_match=="TP",na.rm=TRUE)+sum(percent_match=="FP",na.rm=TRUE)) 
  
  resultsTable2[1,i]<-Sensitivity
  resultsTable2[2,i]<-Specificity
  resultsTable2[3,i]<-PPV
  resultsTable2[4,i]<-NPV
  resultsTable2[5,i]<-Accuracy
  
  return (resultsTable2)
}

#Print ROC curve:
roc.curve=function(s,print=FALSE){
  Ps=(S>s)*1
  FP=sum((Ps==1)*(Y==0))/sum(Y==0)
  TP=sum((Ps==1)*(Y==1))/sum(Y==1)
  if(print==TRUE){
    print(table(Observed=Y,Predicted=Ps))
  }
  vect=c(FP,TP)
  names(vect)=c("FPR","TPR")
  return(vect)
}

#insert diagonal for Srivastava:
insert.diag <- function(M,d,start=c(1,1),dir=c(1,1)) {
  sq <- seq_along(d)-1
  indices <- sapply(1:2,function(i) start[i] + dir[i]*sq)
  stopifnot(all(indices>0))
  stopifnot(all(indices[,1]<=nrow(M)))
  stopifnot(all(indices[,2]<=ncol(M)))  
  
  M[indices] <- d
  M
}
tr <- function(M) {
  
  return(sum(diag(M)))
  
}


#Algorithms------------------------------------------------------------------
alpha<-0.0027

# Hotelling
my.hotelling <- function(x, n, mu0, sigma0){
  sigma0.inv <- solve(sigma0)
  return (as.numeric(n * as.numeric(x-mu0) %*% as.matrix(sigma0.inv)) %*% as.numeric(t(x-mu0)))
}

my.test.hot <- function(x, n, alpha, mu0, sigma0){
  hot <- my.hotelling(x = x, n = n, mu0 = mu0, sigma0 = sigma0)
  p <- length(x)
  hot.ucl <- qchisq(p=1-alpha, df = p)
  reject <- hot > hot.ucl
  return(reject)
}

#Mass Univariate
my.mas <- function(x, alpha){
  p <- length(x)
  alpha.star <- 1-(1-alpha)^(1/p)
  mas.ucl <- qnorm(p=1-alpha.star/2)
  return (sum( abs(x)> mas.ucl ))
}

my.test.mas <- function(x, alpha){
  p <- length(x)
  alpha.star <- 1-(1-alpha)^(1/p)
  mas.ucl <- qnorm(p=1-alpha.star/2)
  reject <- sum( abs(x)> mas.ucl ) >= 1
  return(reject)
}

  
#Phase 1:--------------------------------------------------------

phase1_mass_adjus<-as.matrix(train.matrix)
phase1_matrix<-as.matrix(train.matrix)
phase1_mass_adjus<-as.data.frame(train.matrix)
phase1_matrix<-as.data.frame(train.matrix)

periods<-nrow(phase1_matrix)

p <- length(phase1_matrix)
param.mean <- sapply(phase1_matrix,mean,na.rm = TRUE)
param.cov <- cov(phase1_matrix) #Identity matrix
param.sd <- sapply(phase1_mass_adjus,FUN =  sd)

statisti.hot<-as.data.frame(matrix(0,periods, 2,F))
statisti.mas<-as.data.frame(matrix(0,periods, 2,F))

colnames(statisti.hot)<-c("sample", "statisti")
colnames(statisti.mas)<-c("sample", "statisti")

rejections.hot<- rep(NA, periods)
rejections.mas<- rep(NA, periods)

#change mass univariate to normal distribution:
for(i in 1:ncol(phase1_mass_adjus)){
  phase1_mass_adjus[,i]<-(phase1_mass_adjus[,i]-param.mean[i])/param.sd[i]
}

#Run algorithem---------------------------------------

for(i in 1:periods){
  #input:
  .data<-phase1_matrix[i,]
  .data_mass<-phase1_mass_adjus[i,]
  n<-nrow(.data)
  N<-nrow(phase1_matrix)
  
  #tests:
  rejections.hot[i] <- my.test.hot(x=.data, n = n, alpha = alpha, mu0 = param.mean, sigma0 = param.cov)
  rejections.mas[i] <- my.test.mas(x=.data_mass, alpha = alpha)
  #save statisti for plot:
  statisti.hot$statisti[i]<-my.hotelling(x=.data, n=n , mu0 = param.mean, sigma0 = param.cov)
  statisti.hot$sample[i]<-i
  statisti.mas$statisti[i]<-my.mas(x=.data, alpha=alpha)
  statisti.mas$sample[i]<-i
}


#Clean data-pahse1-----------------------
hot.ucl <- qchisq(p=1-alpha, df = p)
alpha.star <- 1-(1-alpha)^(1/p)
mas.ucl <- qnorm(p=1-alpha.star/2)


inormalInd<-which(statisti.hot$statisti>hot.ucl, arr.ind = TRUE)
(length(inormalInd)/nrow(train.matrix))*100
train.matrix<-train.matrix[-(inormalInd),]


#Phase 2:--------------------------------------------------------

phase1_mass_adjus<-as.matrix(test.matrix)
phase1_matrix<-as.matrix(test.matrix)
phase1_mass_adjus<-as.data.frame(test.matrix)
phase1_matrix<-as.data.frame(test.matrix)

periods<-nrow(phase1_matrix)

statisti.hot<-as.data.frame(matrix(0,periods, 2,F))
statisti.mas<-as.data.frame(matrix(0,periods, 2,F))

colnames(statisti.hot)<-c("sample", "statisti")
colnames(statisti.mas)<-c("sample", "statisti")

rejections.hot<- rep(NA, periods)
rejections.mas<- rep(NA, periods)

#change mass univariate to normal distribution:
for(i in 1:periods){
  phase1_mass_adjus[i,]<-(as.numeric(as.character(phase1_mass_adjus[i,]))-param.mean)/param.sd
}


#Plot graphs----------------------------------------------------------

plot.algorithem(statisti.hot, hot.ucl)

Tag<-suppressWarnings(as.numeric(as.character(Ichilov$Tag)))
Tag<-as.numeric(Tag)

S.hot=statisti.hot$statisti[!is.na(Tag)]
Y=Tag[!is.na(Tag)]
ROChotelling<-roc(Y,S.hot,percent=TRUE, plot=TRUE, ci=TRUE)

#check algorithm with tags:
percent.match.hot<- rep(NA, periods)
percent.match.mas<- rep(NA, periods)

for(i in 1:periods)
{
  percent.match.hot[i]<-check.tags(tag=Ichilov$Tag[i],reject=rejections.hot[i])
  percent.match.mas[i]<-check.tags(tag=Ichilov$Tag[i],reject=rejections.mas[i])
}

#results - Hotelling:
resultsTable<-ROC1(i=2, percent_match=percent.match.hot, data=test, resultsTable=resultsTable)
resultsTable2<-ROC2(i=2, percent_match=percent.match.hot, data=test,resultsTable2=resultsTable2)

#results - Mass Univariate:
resultsTable<-ROC1(i=3, percent_match=percent.match.mas, data=test, resultsTable=resultsTable)
resultsTable2<-ROC2(i=3, percent_match=percent.match.mas, data=test,resultsTable2=resultsTable2)

#Print result table:
frame()
grid.table(resultsTable)


#Print result2 table:
frame()
grid.table(resultsTable2)

rejections.hot[rejections.hot==FALSE]<-0
rejections.hot[rejections.hot==TRUE]<-1

rejections.mas[rejections.hot==FALSE]<-0
rejections.mas[rejections.hot==TRUE]<-1

Model_Test_Measure(rejections.hot, test$Tag, TRUE, 10)
Model_Test_Measure(rejections.mas, test$Tag, TRUE, 10)
