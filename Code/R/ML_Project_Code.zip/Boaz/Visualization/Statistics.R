library(corrplot);
library(randomForest);
library(nnet);
library(caret)
library(ggplot2); 
library(plotly);

library(magrittr)
library(psych)
library(lsr)
library(ppcor)

library(vcd)
library(rms)
library(e1071)
library(clusterGeneration)
library(devtools)
library(reshape)
library(RCurl)
library(DiscriMiner)
library(reshape2)


#install.packages("reshape2")


###-------------------------------------------Create Data----------------------------------------------###

# Clear workspace
rm(list=ls(all=TRUE)) 

# Read Data
data<-read.csv("/home/gal/Boaz/Shiny Visualization Tool/Data/Data.csv",header=TRUE, sep = ",")

# Check missing - number of missing per column/variable (if they exist, must handle them)
colSums(is.na(data)) 


#######@@@@@@@@@@@@@------------------ Statistics ----------------------@@@@@@@@@@@@@#########

###---------------------------------------- Draw histograms for all vars -------------------------------------------------###

hist(data$PAPD, breaks=100, col="light blue", xlab="X", main="Value frequency of PAPD")
hist(data$CVP, breaks=50, col="light blue", xlab="X", main="Value frequency of CVP")
hist(data$ArtBPM, breaks=100, col="light blue", xlab="X", main="Value frequency of ArtBPM")
hist(data$ArtBPS, breaks=100, col="light blue", xlab="X", main="Value frequency of ArtBPS")
hist(data$HR, breaks=100, col="light blue", xlab="X", main="Value frequency of HR")
hist(data$RR_total, breaks=100, col="light blue", xlab="X", main="Value frequency of RR_total")
hist(data$RR_mandatory, breaks=100, col="light blue", xlab="X", main="Value frequency of RR_mandatory")
hist(data$Spo2, breaks=100, col="light blue", xlab="X", main="Value frequency of Spo2")
hist(data$ST1, breaks=100, col="light blue", xlab="X", main="Value frequency of ST1")
hist(data$ST2, breaks=100, col="light blue", xlab="X", main="Value frequency of ST2")
hist(data$ST3, breaks=100, col="light blue", xlab="X", main="Value frequency of ST3")
hist(data$Fio2, breaks=100, col="light blue", xlab="X", main="Value frequency of Fio2")

# Draw histograms after log transformation (for some vars)
hist(log(data$CVP+60), breaks=50, col="light blue", xlab="X", main="Value frequency of log(CVP+60)")
hist(log(data$RR_total), breaks=100, col="light blue", xlab="X", main="Value frequency of log(RR_total)")
hist(log(data$Spo2), breaks=100, col="light blue", xlab="X", main="Value frequency of log(Spo2)")


###@@@@@@@@@@@@@--------------------- Draw Histograms with alarm frequencies ------------------@@@@@@@@@@@@@@@@@###

# RUN FUNCTIONS:

# ********************* draw Both Graphs Function *********************

drawGraphs <- function(varName, legendLocation)
{
  varNum <- grep(varName, colnames(data))
  
  par(mfrow=c(2,1), bg="white") # Space for 2 graphs
  
  # Stacked Bar Plot - Alarm by varName - Frequency
  counts <- table(data$Tag,  cut(data[,varNum],50))
  barplot(counts, main=(paste("Alarm by ", varName)),
          xlab=varName, col=c("cadetblue","firebrick"), ylab = "Frequency",
          legend = c("Not Alarm","Alarm"), args.legend = list(x = legendLocation))
  
  # Stacked Bar Plot - Alarm by varName - Proportion
  counts <- table(data$Tag,  cut(data[,varNum],50))
  countsProp   <- counts #Copy counts
  
  for (i in 1:ncol(counts))
  {
    sum = counts[1,i] + counts[2,i]
    
    if (sum != 0)
    {
      countsProp[1,i] = as.double(counts[1,i] / sum)
      countsProp[2,i] = as.double(counts[2,i] / sum)    
    }
  }
  
  barplot(countsProp,  
          xlab=varName, col=c("cadetblue","firebrick"), ylab = "Proportion",
          #        legend = rownames(counts),args.legend = list(x = "topleft",inset=c(0.9,0), xpd = TRUE))
  )
  
  par(mfrow=c(1,1), bg="white")
  
}


# ********************* draw Only Frequency Graph Function ********************* #

drawGraph_Frequency <- function(varName, legendLocation)
{
  varNum <- grep(varName, colnames(data))
  
  # Stacked Bar Plot - Alarm by varName
  counts <- table(data$Tag,  cut(data[,varNum],50))
  barplot(counts, main=(paste("Alarm by ", varName)),
          xlab=varName, col=c("cadetblue","firebrick"), ylab = "Frequency",
          legend = c("Not Alarm","Alarm"), args.legend = list(x = legendLocation))
}


# ********************* draw Only Proportion Function *********************#

drawGraph_Proportion <- function(varName, legendLocation)
{
  varNum <- grep(varName, colnames(data))
  
  counts <- table(data$Tag,  cut(data[,varNum],50))
  countsProp   <- counts #Copy counts
  
  for (i in 1:ncol(counts))
  {
    sum = counts[1,i] + counts[2,i]
    
    if (sum != 0)
    {
      countsProp[1,i] = as.double(counts[1,i] / sum)
      countsProp[2,i] = as.double(counts[2,i] / sum)    
    }
  }
  
  # Stacked Bar Plot - Alarm by varName
  barplot(countsProp,  
          xlab=varName, col=c("cadetblue","firebrick"), ylab = "Proportion",
          #        legend = rownames(counts),args.legend = list(x = "topleft",inset=c(0.9,0), xpd = TRUE))
  )
  
  par(mfrow=c(1,1), bg="white")
}

# ****************************** Functions end




# Draw graphs for all vars
drawGraphs("PAPD", "topleft")
drawGraphs("CVP", "topright")
drawGraphs("ArtBPM", "topright")
drawGraphs("ArtBPS", "topleft")
drawGraphs("HR", "topleft")
drawGraphs("RR_total", "topright")
drawGraphs("RR_mandatory", "topright")
drawGraphs("Spo2", "topleft")
drawGraphs("ST1", "topleft")
drawGraphs("ST2", "topleft")
drawGraphs("ST3", "topleft")
drawGraphs("Fio2", "topright")

#If only one of the graphs is needed:
drawGraph_Frequency("ST1", "topleft")
drawGraph_Proportion("ST1", "topleft")







###@@@@@@@@@@@@@--------------------- All kinds of stuff ------------------@@@@@@@@@@@@@@@@@###

levels(factor(data$term)) #column different values

rowSums(is.na(data)) # Number of missing per row

colSums(is.na(data)) # Number of missing per column/variable

table(data$term) #column different values with amounts

length(unique(data$member_id)) #column number of unique values

data$termnew <- 0 #Add column

#Variable Frequency
hist(data$PAPD, breaks=100, col="green", xlab="X", main="Value frequency of v1")

#Variable Boxplot
boxplot(data[,1], horizontal=TRUE, main="v1")

#scatter plot - 2 variables
plot(data[,14],data[,15])

#scatter plot matrix
scatterMatrix <- pairs.panel(data[,3:15])

#covariance matrix
cov(data[,3:15])

#correlation matrix
correlation <- cor(data[,3:15])
corrplot <- corrplot(correlation)
