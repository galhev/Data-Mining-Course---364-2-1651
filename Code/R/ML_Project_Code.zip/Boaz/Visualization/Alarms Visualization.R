
library(plotly)
#------------alarm types------------------------------------

Ichilov<-read.csv("/home/gal/Boaz/Shiny Visualization Tool/Data/df.csv",header=TRUE, sep = ",")

Ichilov_true<-Ichilov[Ichilov$Tag==1,]   
agg_type <-aggregate(Tag ~ Type,data = Ichilov_true,FUN=sum)
colnames(agg_type)<-c("Alarm Type","Total of True Alarms")

frame()
grid.table(agg_type)


#Total alarm per type and Day-------------------------------------------------------------
Ichilov$Count<-1
Ichilov$Time<-as.POSIXlt(Ichilov$Time)
Ichilov$Day<-(Ichilov$Time)$wday
Ichilov$Hour<-(Ichilov$Time)$hour
Ichilov$Date<-trunc((as.Date(Ichilov$Time)), "days")
 
Ichilov[Ichilov$Day==0,"Day"]<-"Sunday"
Ichilov[Ichilov$Day==1,"Day"]<-"Monday"
Ichilov[Ichilov$Day==2,"Day"]<-"Tuesday"
Ichilov[Ichilov$Day==3,"Day"]<-"Wednesday"
Ichilov[Ichilov$Day==4,"Day"]<-"Thursday"
Ichilov[Ichilov$Day==5,"Day"]<-"Friday"
Ichilov[Ichilov$Day==6,"Day"]<-"Suterday"

agg_total_alarm <- aggregate(Ichilov$Count ~ Ichilov$Day+ Ichilov$Hour+ Ichilov$Date+ Ichilov$Type, data = Ichilov, FUN = sum)     

colnames(agg_total_alarm)<-c('Day', 'Hour' , 'Date','Alram_Type' ,'Number_of_Alarms')

agg_total_alarm <-within(agg_total_alarm, Day_Hour <- paste(agg_total_alarm$Day, agg_total_alarm$Hour, sep='_'))

#Boxplot for each WeekDay per Alarm Type:

#Bradycardia1
V.TAC<-agg_total_alarm[agg_total_alarm$Alram_Type=="Bradycardia1",]
(plot_ly(V.TAC, x=agg_total_alarm$Day_Hour, y = agg_total_alarm$Number_of_Alarms, color = agg_total_alarm$Day, type = "box"))
#Hypovolemia1
V.FIB<-agg_total_alarm[agg_total_alarm$Alram_Type=="Hypovolemia1",]
(plot_ly(V.FIB, x=agg_total_alarm$Day_Hour, y = agg_total_alarm$Number_of_Alarms, color = agg_total_alarm$Day, type = "box"))
#SVT
TACHY<-agg_total_alarm[agg_total_alarm$Alram_Type=="SVT",]
(plot_ly(TACHY, x=agg_total_alarm$Day_Hour, y = agg_total_alarm$Number_of_Alarms, color = agg_total_alarm$Day, type = "box"))
#Tachycardia
ASYST<-agg_total_alarm[agg_total_alarm$Alram_Type=="Tachycardia",]
(plot_ly(ASYST, x=agg_total_alarm$Day_Hour, y = agg_total_alarm$Number_of_Alarms, color = agg_total_alarm$Day, type = "box"))

#--------------------------------------------------------------------------

#Total results per Day of the week:----------------------------------------
tab <- table(Ichilov$Day,Ichilov$Tag)
tab <- cbind(tab, Total = sum(Ichilov$Tag==1)+sum(Ichilov$Tag==0))

true_alarm <- aggregate(Ichilov$Tag=='1' ~ Ichilov$Day+Ichilov$Hour+Ichilov$Date, data = Ichilov, FUN = sum)     

colnames(true_alarm)<-c('Day', 'Hour' , 'Date' ,'sum_Tag')

true_alarm <-within(true_alarm, Day_Hour <- paste(true_alarm$Day, true_alarm$Hour, sep='_'))



#Boxplot for each WeekDay - True Alarms:

ans<-axis_func("WeekDay","Frequency")
plot_ly(y = true_alarm$sum_Tag, type = "box",color=true_alarm$Day_Hour)%>%layout(xaxis = ans[[1]], yaxis = ans[[2]])

false_alarm <- aggregate(Ichilov$Tag=='0' ~ Ichilov$Date+Ichilov$Hour, data = Ichilov, FUN = sum)


#______________________________________________________________________

#Boxplot for each WeekDay per Alarm Type - Total Alarms (False and True):
library("plyr")

total_alarm <- aggregate(mimic$Chan=='3'|mimic$Chan=='1' ~ mimic$Day+mimic$Hour, data = mimic, FUN = sum)

colnames(total_alarm)<-c('Day', 'Hour' , 'sum_Chan')

total_alarm <-within(total_alarm, Day_Hour <- paste(total_alarm$Day, total_alarm$Hour, sep='_'))

(plot_ly(total_alarm, x=total_alarm$Day_Hour, y = total_alarm$sum_Chan, color = total_alarm$Day, type = "boxplot"))



axis_func<-function(p1,p2)
{
  f <- list(
    family = "Courier New, monospace",
    size = 18,
    color = "#7f7f7f"
  )
  x <- list(
    title = p1,
    titlefont = f
  )
  y <- list(
    title = p2,
    titlefont = f
  )
  ans_list<-list(x,y)
  return(ans_list)
}


