library("corrplot")
library("zoo")
library("pROC")
library('qcc')
library('MASS')
library('ggplot2')
library('mvtnorm')
library("plyr")
library("plotly")
require(shiny)
library(ggplot2)
library(reshape)
library(plotly)
library("gplots")
library("rms")
require(gridExtra)
require(lattice)


# rm(list = ls()) ## cealn Worksapce

#-------------------------------------------------------------------------

ui <- shinyUI(fluidPage(  tags$head(
  
  tags$link(rel = "stylesheet", type = "text/css", href = "bootstrap.css")),

  titlePanel(title = "Exploratory statistics"),
  
  sidebarLayout(
    sidebarPanel(br(),
                uiOutput("x"),
                 br(),
                 uiOutput("y"),
                 br()
                 
                 
                 
    ),
    
    mainPanel(
      tabsetPanel(
        type = "tab",
        tabPanel("Ichilov DB",
                 fluidRow(
                   h4(strong("Tel Aviv Sourasky Medical Center")),
                   p("Tel Aviv Sourasky Medical Center (Ichilov) is the second largest and one of the most progressive full-service healthcare treatment and research institutions in Israel.")),
                 helpText("For more information about Sourasky Medical Center please go to the following address: ",
                          a(href="http://www.tasmc.org.il/sites/en/About/Pages/About.aspx", target="_blank", " Sourasky Medical Center Website")),
                 tags$img(src='ICU3d.jpg',height=200, width=300,align = "right")
        ),
        
        tabPanel("Summary", 
                 fluidRow(
                   h4("Descriptive Statistics"),
                   br(),
                   strong("Signals Description:"),
                   conditionalPanel(condition = "input.value1 == 'ArtBPS'||input.value2 == 'ArtBPS'", p("ArtBPS: Arterial Pressure Systolic")),
                   conditionalPanel(condition = "input.value1 == 'ArtBPM'||input.value2 == 'ArtBPM'", p("ArtBPM: Arterial Pressure Mean")),
                   conditionalPanel(condition = "input.value1 == 'PAPD'||input.value2 == 'PAPD'", p("PAPD: Pulmonary Artery Pressure Diastolic")),
                   conditionalPanel(condition = "input.value1 == 'RR_mandatory'||input.value2 == 'RR Mandatory'", p("RR Mandatory: Mechanical Respiratory Rate")),
                   conditionalPanel(condition = "input.value1 == 'RR_total'||input.value2 == 'RR_total'", p("RR Total: Total Respiratory Rate")),
                   conditionalPanel(condition = "input.value1 == 'Fio2'||input.value2 == 'Fio2'", p("Fio2: Fraction of Inspired Oxygen")),
                   conditionalPanel(condition = "input.value1 == 'PAPSys'||input.value2 == 'PAPSys'", p("PAPSys: systolic pulmonary arterial pressure")),
                   conditionalPanel(condition = "input.value1 == 'PULSE'||input.value2 == 'PULSE'", p("PULSE: pulse rate")),
                   conditionalPanel(condition = "input.value1 == 'HR'||input.value2 == 'HR'", p("HR: heart rate")),
                   conditionalPanel(condition = "input.value1 == 'ABP'||input.value2 == 'ABP'", p("ABP: arterial blood pressure (invasive, from one of the radial arteries)")),
                   conditionalPanel(condition = "input.value1 == 'ART'||input.value2 == 'ART'", p("ART: arterial blood pressure (invasive, from the other radial artery)")),
                   conditionalPanel(condition = "input.value1 == 'CVP'||input.value2 == 'CVP'", p("CVP: central venous pressure")),
                   conditionalPanel(condition = "input.value1 == 'PAP'||input.value2 == 'PAP'", p("PAP: pulmonary arterial pressure")),
                   conditionalPanel(condition = "input.value1 == 'PLETH'||input.value2 == 'PLETH'", p("PLETH: uncalibrated raw output of fingertip plethysmograph")),
                   conditionalPanel(condition = "input.value1 == 'RESP'||input.value2 == 'RESP'", p("RESP: uncalibrated respiration waveform, estimated from thoracic impedance")),
                   conditionalPanel(condition = "input.value1 == 'NBP'||input.value2 == 'NBP'", p("NBP: noninvasive arterial blood pressure")),
                   conditionalPanel(condition = "input.value1 == 'CO'||input.value2 == 'CO'", p("CO: cardiac output")),
                   conditionalPanel(condition = "input.value1 == 'CO2'||input.value2 == 'CO2'", p("CO2: carbon dioxide")),
                   conditionalPanel(condition = "input.value1 == 'Spo2'||input.value2 == 'Spo2'", p("SpO2: oxygen saturation (from fingertip plethysmography)")),
                   conditionalPanel(condition = "input.value1 == 'I'||input.value2 == 'I'", p("ECG (electrocardiographic) waveforms include: AVF, AVL, AVR, I, II, III, MCL, MCL1, V, V1, and V2")),
                   conditionalPanel(condition = "input.value1 == 'II'||input.value2 == 'II'", p("ECG (electrocardiographic) waveforms include: AVF, AVL, AVR, I, II, III, MCL, MCL1, V, V1, and V2")),
                   conditionalPanel(condition = "input.value1 == 'III'||input.value2 == 'III'", p("ECG (electrocardiographic) waveforms include: AVF, AVL, AVR, I, II, III, MCL, MCL1, V, V1, and V2")),
                   conditionalPanel(condition = "input.value1 == 'V'||input.value2 == 'V'", p("ECG (electrocardiographic) waveforms include: AVF, AVL, AVR, I, II, III, MCL, MCL1, V, V1, and V2")),
                   conditionalPanel(condition = "input.value1 == 'MCL'||input.value2 == 'MCL'", p("ECG (electrocardiographic) waveforms include: AVF, AVL, AVR, I, II, III, MCL, MCL1, V, V1, and V2")),
                   conditionalPanel(condition = "input.value1 == 'MCL1'||input.value2 == 'MCL1'", p("ECG (electrocardiographic) waveforms include: AVF, AVL, AVR, I, II, III, MCL, MCL1, V, V1, and V2")),
                   conditionalPanel(condition = "input.value1 == 'AVF'||input.value2 == 'AVF'", p("ECG (electrocardiographic) waveforms include: AVF, AVL, AVR, I, II, III, MCL, MCL1, V, V1, and V2")),
                   conditionalPanel(condition = "input.value1 == 'AVL'||input.value2 == 'AVL'", p("ECG (electrocardiographic) waveforms include: AVF, AVL, AVR, I, II, III, MCL, MCL1, V, V1, and V2")),
                   conditionalPanel(condition = "input.value1 == 'AVR'||input.value2 == 'AVR'", p("ECG (electrocardiographic) waveforms include: AVF, AVL, AVR, I, II, III, MCL, MCL1, V, V1, and V2")),
                   br(),
                   column(10,textOutput("val1"),p("Michael ALRAM"), verbatimTextOutput("summary1"),p("No ALRAM"), verbatimTextOutput("summary1FALSE")),
                   column(10,textOutput("val2"),p("Michael ALRAM"), verbatimTextOutput("summary2"),p("No ALRAM"),verbatimTextOutput("summary2FALSE")))),
        tabPanel("Boxplot", fluidRow(plotlyOutput("myboxPlot"),plotlyOutput("myboxPlotEvent"), plotlyOutput("myboxPlot2"), plotlyOutput("myboxPlotEvent2"))),
        tabPanel("Histogram", 
                 fluidRow( h4("Histogram for total data:"),
                           plotlyOutput("myHistogram"),
                           h4("Histogram - False Alarms:"),
                           plotlyOutput("myHistogramTagIC"),
                           h4("Histogram - True Alarms:"),
                           plotlyOutput("myHistogramTagOC"),
                           h4("Histogram for total data:"),
                           plotlyOutput("myHistogram2"),
                           h4("Histogram - False Alarms:"),
                           plotlyOutput("myHistogram2TagIC"),
                           h4("Histogram - True Alarms:"),
                           plotlyOutput("myHistogram2TagOC"))),
        tabPanel("Date Time Plot",
                 fluidRow(plotlyOutput("DateTime"), plotlyOutput("DateTime2"))),
        tabPanel("Scatter Plot",plotlyOutput("myScatterPlot")),
        tabPanel("Correlation Matrix",plotOutput("myCorrelationMatrix"))
       
      )
    )
  )
))

