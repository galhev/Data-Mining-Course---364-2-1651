
server <- shinyServer(function(input,output, session) {
  options(warn=-1)
  
  data<-read.csv("./Data/Data.csv",header=TRUE, sep = ",")
  
  #drop irrelevant fileds from UI:
  Ichilov<-dropFields(data)
  Ichilov_data<-changeTag(data)
  
  # Return the requested dataset
  datasetInputChoices <- reactive({names(Ichilov)})
  
  datasetInput <- reactive({Ichilov_data})
  
  
  output$x <-renderUI({selectInput("value1", "Select the first variable", choices = datasetInputChoices())})
  output$y <-renderUI({selectInput("value2", "Select the second variable", choices = datasetInputChoices())})
  
  output$val1<-renderText(input$value1)
  output$val2<-renderText(input$value2)
  
  output$myboxPlot  <- renderPlotly({
    mimic<-datasetInput()
    parameter1<-mimic[,input$value1]
    ans<-axis_func(".",input$value1)
    plot_ly(y = parameter1, type = "box",color=mimic$Tag)%>%layout(xaxis = ans[[1]], yaxis = ans[[2]])})
  
  output$myboxPlotEvent  <- renderPlotly({
    mimic<-datasetInput()
    parameter1<-mimic[,input$value1]
    ans<-axis_func(".",input$value1)
    plot_ly(y = parameter1, type = "box",color=mimic$Type)%>%layout(xaxis = ans[[1]], yaxis = ans[[2]])})

  
  output$myboxPlot2  <- renderPlotly({
    mimic<-datasetInput()
    parameter2<-mimic[,input$value2]
    ans<-axis_func(".",input$value2)
    plot_ly(y = parameter2, type = "box",color=mimic$Tag)%>%layout(xaxis = ans[[1]], yaxis = ans[[2]])})
  
  output$myboxPlotEvent2  <- renderPlotly({
    mimic<-datasetInput()
    parameter2<-mimic[,input$value2]
    ans<-axis_func(".",input$value2)
    plot_ly(y = parameter2, type = "box",color=mimic$Type)%>%layout(xaxis = ans[[1]], yaxis = ans[[2]])})
  
  
  output$myHistogram  <- renderPlotly({
    mimic<-datasetInput()
    parameter1<-mimic[,input$value1]
    ans<-axis_func(input$value1,"Frequency")
    plot_ly(x = parameter1, type = "histogram")%>%layout(xaxis = ans[[1]], yaxis = ans[[2]])})
  
  output$myHistogramTagOC  <- renderPlotly({
    mimic<-datasetInput()
    parameter1<-mimic[mimic$Tag=="Alarm",input$value1]
    ans<-axis_func(input$value1,"Frequency")
    plot_ly(x = parameter1, type = "histogram",color="red")%>%layout(xaxis = ans[[1]], yaxis = ans[[2]])})
  
  output$myHistogramTagIC  <- renderPlotly({
    mimic<-datasetInput()
    parameter1<-mimic[mimic$Tag=="No Alarm",input$value1]
    ans<-axis_func(input$value1,"Frequency")
    plot_ly(x = parameter1, type = "histogram",color="green")%>%layout(xaxis = ans[[1]], yaxis = ans[[2]])})
  
  
  output$myHistogram2  <- renderPlotly({
    mimic<-datasetInput()
    parameter2<-mimic[,input$value2]
    ans<-axis_func(input$value2,"Frequency")
    plot_ly(x = parameter2, type = "histogram")%>%layout(xaxis = ans[[1]], yaxis = ans[[2]])})
  
  
  output$myHistogram2TagOC  <- renderPlotly({
    mimic<-datasetInput()
    parameter2<-mimic[mimic$Tag=="Alarm",input$value2]
    ans<-axis_func(input$value2,"Frequency")
    plot_ly(x = parameter2, type = "histogram",color="red")%>%layout(xaxis = ans[[1]], yaxis = ans[[2]])})
  
  output$myHistogram2TagIC  <- renderPlotly({
    mimic<-datasetInput()
    parameter2<-mimic[mimic$Tag=="No Alarm",input$value2]
    ans<-axis_func(input$value2,"Frequency")
    plot_ly(x = parameter2, type = "histogram",color="green")%>%layout(xaxis = ans[[1]], yaxis = ans[[2]])})
  
  
  output$DateTime  <- renderPlotly({
    mimic<-datasetInput()
    parameter1<-mimic[,input$value1]
    ans<-axis_func("Date and Time", input$value1)
    plot_ly(mimic, x = mimic$Time, y = parameter1,color=Tag, mode = "markers")%>%layout(xaxis = ans[[1]], yaxis = ans[[2]])})
  
  output$DateTime2  <- renderPlotly({
    mimic<-datasetInput()
    parameter2<-mimic[,input$value2]
    ans<-axis_func("Date and Time", input$value2)
    plot_ly(mimic, x = mimic$Time, y = parameter2, color=Tag, mode = "markers")%>%layout(xaxis = ans[[1]], yaxis = ans[[2]])})
  
  output$myScatterPlot  <- renderPlotly({
    mimic<-datasetInput()
    parameter1<-mimic[,input$value1]
    parameter2<-mimic[,input$value2]
    ans<-axis_func(input$value1, input$value2)
    plot_ly(mimic, x = parameter1, y = parameter2,color=Tag, mode = "markers")%>%layout(xaxis = ans[[1]], yaxis = ans[[2]])})
  
  output$summary1 <- renderPrint({
    dataset <- datasetInput()
    parameter1<-dataset[dataset$Tag=="Alarm",input$value1]
    x1<-suppressWarnings(as.numeric(as.character(parameter1)))
    suppressWarnings(summary(x1))
    
  })
  
  output$summary1FALSE <- renderPrint({
    dataset <- datasetInput()
    parameter1<-dataset[dataset$Tag=="No Alarm",input$value1]
    x1<-suppressWarnings(as.numeric(as.character(parameter1)))
    suppressWarnings(summary(x1))
    
  })
  
  output$summary2 <- renderPrint({
    dataset <- datasetInput()
    parameter2<-dataset[dataset$Tag=="Alarm",input$value2]
    x2<-suppressWarnings(as.numeric(as.character(parameter2)))
    suppressWarnings(summary(x2))
    
  })
  
  output$summary2FALSE <- renderPrint({
    dataset <- datasetInput()
    parameter2<-dataset[dataset$Tag=="No Alarm",input$value2]
    x2<-suppressWarnings(as.numeric(as.character(parameter2)))
    suppressWarnings(summary(x2))
    
  })
  
  output$myCorrelationMatrix <- renderPlot({
    dat <- datasetInput()
    data<-mimic_use(dat)
    z <- cor(data,use="p")
    #levelplot(z)
    corrplot(z, method="color")
    })
  
  output$downloadData <- downloadHandler(
    filename = function() { paste(input$dataset, '.csv', sep=',') },
    content = function(file) {
      write.csv(datasetInput(), file)})
  
})#shiny server



#---------------------------------------------------------------------
dropFields <- function(mimic) {
  drops <- c("Time","PatientID", "Type","Tag")
  mimicNew<-as.data.frame(mimic[ , !(names(mimic) %in% drops)])
  return(mimicNew)
}

axis_func<-function(p1,p2)
{
  f <- list(
    family = "Courier New, monospace",
    size = 18,
    color = "#7f7f7f"
  )
  x <- list(
    title = p1,
    titlefont = f
  )
  y <- list(
    title = p2,
    titlefont = f
  )
  ans_list<-list(x,y)
  return(ans_list)
}


mimic_use<-function(mimic){
  
  drops <- c("Time","Type", "PatientID","Tag")
  mimic_matrix<-as.data.frame(mimic[ , !(names(mimic) %in% drops)])
  
  for (i in 1:ncol(mimic_matrix))
  {
    (mimic_matrix[,i]<-as.numeric(as.character(mimic_matrix[,i])))
  }
  
  result<-mimic_matrix
  return(result)
}

changeTag<-function(Ichilov_data){
  Ichilov_data[Ichilov_data$Tag==1,"Tag"]<-"Alarm"
  Ichilov_data[Ichilov_data$Tag==0,"Tag"]<-"No Alarm"
  return(Ichilov_data)
}
