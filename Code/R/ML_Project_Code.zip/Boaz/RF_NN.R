library(corrplot);
library(randomForest);
library(nnet);
library(caret)
library(ggplot2); 
library(plotly);
library(e1071)
library(clusterGeneration)
library(devtools)
library(reshape)
library(RCurl)
library(ROCR)
library(DiscriMiner)
library(gridExtra)

save.image("C:/R stuff/ML course/WorkspaceLiel25_02.RData")

#install.packages("gridExtra")
#install.packages("drat", repos="https://cran.rstudio.com")
#drat:::addRepo("dmlc")
#install.packages("mxnet")

################## ------------------------------Create Data----------------------------------------------

# Clear workspace
rm(list=ls(all=TRUE)) 

# Read Data
#data <- as.data.frame(read.csv("C:/R stuff/ML course/PatientsData2202.csv"))

data <- as.data.frame(read.csv("C:/R stuff/ML course/PatientsData2302-30k.csv"))

################## ------------------------------ Down Sampling----------------------------------------------

#By Tag
data0 <- data[data$Tag == 0,]
data1 <- data[data$Tag == 1,]

rand4      <- sample(4, nrow(data0), replace=T)
folds.prob <- as.numeric(table(rand4)/length(rand4))
data0chosen <- data0[rand4 == 1,]

dataFinal <- rbind(data1,data0chosen)
dataFinal <- dataFinal[sample(nrow(dataFinal)),]

data <- dataFinal

write.csv(data, file='C:/R stuff/ML course/PatientsData2202Final.csv')


#Again By Tachikardia
dataCutIndices <- createDataPartition(y=data$Type,p=0.75,list=FALSE)
dataCut <- data[dataCutIndices,]

dataTac <- dataCut[dataCut$Type == ", Tachycardia",]
dataNotTac<- dataCut[dataCut$Type != ", Tachycardia",]

rand2      <- sample(2, nrow(dataTac), replace=T)
dataTacChosen <- dataTac[rand2 == 1,]

dataFinal <- rbind(dataNotTac,dataTacChosen)
dataFinal <- dataFinal[sample(nrow(dataFinal)),]

data <- dataFinal

write.csv(data, file='C:/R stuff/ML course/PatientsData2302-30k.csv')

#Take out 80% of data
#dataCutIndices <- createDataPartition(y=data$Type,p=0.8,list=FALSE)
#dataCut <- data[dataCutIndices,]

#table(dataCut$Type)
#table(dataCut$Tag)

################## ------------------------------ Split data to train and test: -------------------------------
################## 
################## Choose between A (full data) or B (partial data) 

### --------------------------------------- A. Split data

#Split to train and test data
trainIndices <- createDataPartition(y=data$Tag,p=0.6666,list=FALSE)
data.train <- data[trainIndices,]
data.test <- data[-trainIndices,]

rm(trainIndices)

##--------- Split to data and tags
df.train <- data.train[,3:14]
df.test <- data.test[,3:14]

df.train.tags <- data.train[,15]
df.test.tags <- data.test[,15]

rm(data.train, data.test) 

### --------or--------------------B. Split data Partial (without tagging variables)

dataPartial <- data[,8:16]

#Split to train and test data
trainIndices <- createDataPartition(y=dataPartial$Tag,p=0.6666,list=FALSE)

dataPartial.train <- dataPartial[trainIndices,]
dataPartial.test <- dataPartial[-trainIndices,]

rm(trainIndices)

##--------- Split to data and tags
df.train <- dataPartial.train[,1:7]
df.test <- dataPartial.test[,1:7]

df.train.tags <- dataPartial.train[,8]
df.test.tags <- dataPartial.test[,8]

rm(dataPartial.train, dataPartial.test)

################## @@@@@@------------------------ Functions - run all! -------------------------------

############# -----@ CreateRF ------------------- Random Forest Function - only model-------------------------------

createRF <- function(train.data, train.data.tags, numtrees, numvars, weights)
{
  if (weights == 0)
  {
    rf <- randomForest(as.factor(train.data.tags)~. ,data=train.data , ntree=numtrees, mtry=numvars)
  }
  else
  {
    rf <- randomForest(as.factor(train.data.tags)~. ,data=train.data , ntree=numtrees, mtry=numvars, classwt=weights)
  }
  return (rf)
}

############# -----@ createForest_CV_accuary ---- Random Forest + CV accuracy----------------------------------------------

#@@@ function for estimating a random forest with a given number of trees and variables for each tree
#@@@ with cv

createForest_CV_accuary <- function(train.data, train.data.tags, ntreeVal, mtryVal, cv_size)
{
  acc.folds   <- matrix(0, cv_size, 1)
  folds      <- sample(cv_size, nrow(train.data), replace=T)
  folds.prob <- as.numeric(table(folds)/length(folds))
  for(fold in 1:cv_size)
  {
    # Train forest
    rf <- createRF(train.data[folds!=fold,], train.data.tags[folds!=fold], ntreeVal, mtryVal)
    
    # Predict for test fold and compute error rates
    preds <- predict(rf, newdata=train.data[folds==fold,], type='response')
    acc.folds[fold,] <- sum(preds==train.data.tags[folds==fold])/length(train.data.tags[folds==fold])
  }
  
  # Calc average accuracy
  accuracy <- apply(apply(acc.folds, 2, function(x){x*folds.prob}),2,sum)
  print(paste0("Random Forest with ",ntreeVal," trees & ",mtryVal," vars-per-tree"," CV-",cv_size," average accuracy: ", accuracy))
  
  return(list(acc.folds, accuracy))
}

############# -----@ createForest_CV_byMeasure -- Random Forest + CV by chosen measure ----------------------------------------------
createForest_CV_byMeasure <- function(train.data, train.data.tags, measure, weights, ntreeVal, mtryVal, cv_size)
{
  measure.folds   <- matrix(0, cv_size, 1)
  folds      <- sample(cv_size, nrow(train.data), replace=T)
  folds.prob <- as.numeric(table(folds)/length(folds))
  for(fold in 1:cv_size)
  {
    # Train forest
    rf <- createRF(train.data[folds!=fold,], train.data.tags[folds!=fold], ntreeVal, mtryVal, weights)
    measures <- Model_Test_Measure(rf, "randomForest", train.data[folds==fold,], train.data.tags[folds==fold], FALSE, 10)
    measureNum <- grep(measure, colnames(measures))
    measure.folds[fold,] <- measures[,measureNum]
  }
  
  # Calc average accuracy
  averageMeasure <- apply(apply(measure.folds, 2, function(x){x*folds.prob}),2,sum)
  print(paste0("Random Forest with ",ntreeVal," trees & ",mtryVal," vars-per-tree"," CV-",cv_size," average ", measure, ": ", averageMeasure))
  
  return(list(measure.folds, averageMeasure))
}

############# -----@ Model_Test_Measure --------- Test and measure a given model---------------------------------------------
Model_Test_Measure <- function(model, modelType, test.data, test.data.tags, doPrint, w1) #w1 is alpha error weight
{
  set.seed(3588)
  #w1  #Sensitivity weight
  w2  <- 1   #Specificity weight - beta error weight
  
  c <- w2 / (w2+w1) # Specificity weight, Sensitivity weight is (1-c)
  b <- w1 #Sensitivity times weight vs. Precision
  
  if (modelType == "nnet")
  {
    preds   <- factor(predict(model, newdata=test.data, type='class'))
  } else if (modelType == "randomForest") 
  {
    preds <- predict(model, newdata=test.data, type='response')
  } else
  {
    print("Error, unrecognized model type!")
  }
  
  conf <- confusionMatrix(data=preds, test.data.tags, positive="1")
  
  confMatrix <- conf$table
  
  resultsTable<-(as.data.frame(matrix(ncol=8,nrow=1)))
  #colnames(resultsTable)<-c("Accuracy","Sensitivity","Specificity", "Precision", "F1_score", "Fb_score","weightedAccuracy", "ParmetMeasure", "ParmetMeasureWeighted")
  colnames(resultsTable)<-c("Accuracy","Sensitivity","Specificity", "Precision", "F1_score", "Fb_score","Weighted_Accuracy", "Weighted_Measure")
  
  resultsTable$Accuracy <- round(unname(conf$overall["Accuracy"]), digits = 6)  
  resultsTable$Sensitivity <- round(unname(conf$byClass["Sensitivity"]), digits = 6)  # Also called Recall
  resultsTable$Specificity <- round(unname(conf$byClass["Specificity"]), digits = 6)
  resultsTable$Precision <- round(unname(conf$byClass["Precision"]), digits = 6)
  resultsTable$F1_score <- round(unname(conf$byClass["F1"]), digits = 6)
  resultsTable$Fb_score <- round(unname(( (1+(b^2)) * resultsTable$Precision * resultsTable$Sensitivity ) / ( (b^2) * resultsTable$Precision + resultsTable$Sensitivity )), digits = 6)
  resultsTable$Weighted_Accuracy <- round(unname((c*resultsTable$Specificity + (1-c)*resultsTable$Sensitivity)), digits = 6)
  #resultsTable$ParmetMeasure <- round(unname(sqrt(resultsTable$Sensitivity * resultsTable$Specificity)), digits = 6)
  #resultsTable$ParmetMeasureWeighted <- round(unname(  ((resultsTable$Sensitivity^w1) * (resultsTable$Specificity^w2))^(1/(w1+w2))  ), digits = 6)
  resultsTable$Weighted_Measure <- round(unname(  ((resultsTable$Sensitivity^w1) * (resultsTable$Specificity^w2))^(1/(w1+w2))  ), digits = 6)
  
  if(doPrint == TRUE)
  {
    #Print results:
    print("confusion Matrix:")
    print(confMatrix)
    print(resultsTable)
    
    frame()
    grid.table(resultsTable)
  }
  
  return(resultsTable)
}

############# -----@ createNN ------------------- Neuron Network Function - accuracy + model ----------------------------------

createNN <- function(train.data, train.data.tags, neurons)
{
  nn <- nnet(x=train.data, y=class.ind(train.data.tags), size=neurons, linout=FALSE, softmax=T)
  return (nn)
}

############# -----@ createNN_CV_byMeasure ------ Neural Network + CV by chosen measure ----------------------------------------------

createNN_CV_byMeasure <- function(train.data, train.data.tags, measure, neurons, cv_size)
{
  measure.folds   <- matrix(0, cv_size, 1)
  folds      <- sample(cv_size, nrow(train.data), replace=T)
  folds.prob <- as.numeric(table(folds)/length(folds))
  for(fold in 1:cv_size)
  {
    # Train NN
    nn <- createNN(train.data[folds!=fold,], train.data.tags[folds!=fold], neurons)
    measures <- Model_Test_Measure(nn, "nnet", train.data[folds==fold,], train.data.tags[folds==fold], FALSE, 10)
    measureNum <- grep(measure, colnames(measures))
    measure.folds[fold,] <- measures[,measureNum]
  }
  
  # Calc average accuracy
  averageMeasure <- apply(apply(measure.folds, 2, function(x){x*folds.prob}),2,sum)
  print(paste0("Neural Network with ",neurons," neurons, CV-",cv_size," average ", measure, ": ", averageMeasure))
  
  return(list(measure.folds, averageMeasure))
}

############# -----@ Test_Measure_byThreshold ----------------------------------------------------

Test_Measure_byThreshold <- function(modelRawPreds, test.data.tags, probThreshold, doPrint, w1)
{  
  set.seed(3588)
  #w1        #Sensitivity weight
  w2  <- 1   #Specificity weight - beta error weight
  
  c <- w2 / (w2+w1) # Specificity weight, Sensitivity weight is (1-c)
  b <- w1 #Sensitivity times weight vs. Precision
  
  preds <- matrix(0,length(modelRawPreds[,1]),1)
  preds[modelRawPreds[,2] > probThreshold] <- 1
  factor(preds)
  
  conf <- confusionMatrix(data=preds, test.data.tags, positive="1")
  
  confMatrix <- conf$table
  
  resultsTable<-(as.data.frame(matrix(ncol=8,nrow=1)))
  #colnames(resultsTable)<-c("Accuracy","Sensitivity","Specificity", "Precision", "F1_score", "Fb_score","weightedAccuracy", "ParmetMeasure", "Weighted_Measure")
  colnames(resultsTable)<-c("Accuracy","Sensitivity","Specificity", "Precision", "F1_score", "Fb_score","Weighted_Accuracy", "Weighted_Measure")
  
  resultsTable$Accuracy <- round(unname(conf$overall["Accuracy"]), digits = 6)  
  resultsTable$Sensitivity <- round(unname(conf$byClass["Sensitivity"]), digits = 6)  # Also called Recall
  resultsTable$Specificity <- round(unname(conf$byClass["Specificity"]), digits = 6)
  resultsTable$Precision <- round(unname(conf$byClass["Precision"]), digits = 6)
  resultsTable$F1_score <- round(unname(conf$byClass["F1"]), digits = 6)
  resultsTable$Fb_score <- round(unname(( (1+(b^2)) * resultsTable$Precision * resultsTable$Sensitivity ) / ( (b^2) * resultsTable$Precision + resultsTable$Sensitivity )), digits = 6)
  resultsTable$Weighted_Accuracy <- round(unname((c*resultsTable$Specificity + (1-c)*resultsTable$Sensitivity)), digits = 6)
  #resultsTable$ParmetMeasure <- round(unname(sqrt(resultsTable$Sensitivity * resultsTable$Specificity)), digits = 6)
  #resultsTable$ParmetMeasureWeighted <- round(unname(  ((resultsTable$Sensitivity^w1) * (resultsTable$Specificity^w2))^(1/(w1+w2))  ), digits = 6)
  resultsTable$Weighted_Measure <- round(unname(  ((resultsTable$Sensitivity^w1) * (resultsTable$Specificity^w2))^(1/(w1+w2))  ), digits = 6)
  
  if(doPrint == TRUE)
  {
    #Print results:
    print("confusion Matrix:")
    print(confMatrix)
    print(resultsTable)
    
    frame()
    grid.table(resultsTable)
  }
  
  return(resultsTable)
}

############# -----@ createNN_CV_byMeasure & Threshold------ Neural Network + CV by chosen measure ----------------------------------------------

createNN_CV_byMeasure_threshold <- function(train.data, train.data.tags, measure, neurons, cv_size, thresholds)
{
  measure.folds   <- matrix(0, cv_size, length(thresholds))
  colnames(measure.folds) <- thresholds
  folds      <- sample(cv_size, nrow(train.data), replace=T)
  folds.prob <- as.numeric(table(folds)/length(folds))
  
  for(fold in 1:cv_size)
  {
    # Train NN
    nn <- createNN(train.data[folds!=fold,], train.data.tags[folds!=fold], neurons)
    rawPredsNN   <- predict(nn, newdata=train.data[folds==fold,], type='raw')
    
    for (tNum in 1:length(thresholds))
    {
      t <- thresholds[tNum]
      measures <- Test_Measure_byThreshold(rawPredsNN, train.data.tags[folds==fold], t, FALSE, 10)
      measureNum <- grep(measure, colnames(measures))
      measure.folds[fold,tNum] <- measures[,measureNum]
    }
  }
  
  # Calc average accuracy
  averageMeasure <- matrix(0, 1, length(thresholds))
  colnames(averageMeasure) <- thresholds
  
  print(measure.folds)
  
  for (tNum in 1:length(thresholds))
  {
    t <- thresholds[tNum]
    print(cat("calc x*prob: t ",t, " tnum ",tNum,". now measure.folds[,tNum]: \n"))
    tNum
    measure.folds[,tNum]
    print(cat("end measure.folds[,tNum] \n"))
    
    measureT   <- matrix(0, cv_size, 1)
    
    
    measureT[,1] <- measure.folds[,tNum]
    averageMeasure[,tNum] <- apply(apply(measureT, 2, function(x){x*folds.prob}),2,sum)
  }
  
  print(paste0("Neural Network with ",neurons," neurons, CV-",cv_size," average ", measure, ": ", averageMeasure))
  
  return(list(measure.folds, averageMeasure))
}

############# -----@ axis_func------------------- Axis names Function --------------------------------------------------------

axis_func<-function(p1,p2,xlog)
{
  f <- list(
    family = "Courier New, monospace",
    size = 18,
    color = "#7f7f7f"
  )
  x <- list(
    title = p1,
    titlefont = f, 
    type="linear"
  )
  y <- list(
    title = p2,
    titlefont = f
  )
  
  if (xlog == TRUE)
  {
    x <- list(
      title = p1,
      titlefont = f,
      type = "log"
    )
  }
  
  ans_list<-list(x,y)
  return(ans_list)
}

################## -------------------- Run Algorithms -----------------------------------------------------------------------------

################## --------------------$$$ RF $$$-----------------------------------------------------------------------------

# ---------------------------- RF Choose measure ----------
RF <- createRF(df.train[1:43093,], df.train.tags[1:43093], 20, 3, 0)
Model_Test_Measure(RF, "randomForest", df.train[43094:86162,], df.train.tags[43094:86162], TRUE, 1)
Model_Test_Measure(RF, "randomForest", df.train[43094:86162,], df.train.tags[43094:86162], TRUE, 5)
Model_Test_Measure(RF, "randomForest", df.train[43094:86162,], df.train.tags[43094:86162], TRUE, 10)
Model_Test_Measure(RF, "randomForest", df.train[43094:86162,], df.train.tags[43094:86162], TRUE, 20)
# Chose 10

RF <- createRF(df.train, df.train.tags, 50, 4, c(0.001,1000))
Model_Test_Measure(RF, "randomForest", df.test, df.test.tags, TRUE, 10)

# ---------------------------- RF Choose class weights - Original data----------

alaramClassWeight <- 1:8
rf.measure  <- matrix(0,2,length(alaramClassWeight))

for (weight in alaramClassWeight)
{
  w <- 10^(weight-1)
  print(w)
  RF <- createRF(df.train, df.train.tags, 50, 4, c(10, 0.01))
  measures <- Model_Test_Measure(RF, "randomForest", df.test, df.test.tags, TRUE, 10)
  rf.measure[1,weight] <- w
  rf.measure[2,weight] <- measures$Weighted_Measure
  print(measures$Weighted_Measure)
}

# Compared to no weights:
RF <- createRF(df.train, df.train.tags, 50, 4, 0)
measures <- Model_Test_Measure(RF, "randomForest", df.test, df.test.tags, TRUE, 10)

# ---------------------------- RF Choose class weights - After resampling----------

# ---------------------- Log scale -----
alaramClassWeight <- 1:20
rf.measure  <- matrix(0,2,length(alaramClassWeight))

for (weight in alaramClassWeight)
{
  w <- 2^(weight-5)
  print(paste0("w: ",w))
  RF <- createForest_CV_byMeasure(df.train, df.train.tags, "Weighted_Measure", c(0.001,w), 136, 5, 4)
  rf.measure[1,weight] <- w
  rf.measure[2,weight] <- RF[[2]]
}

dataRF <- data.frame(t(rf.measure[]))

pRF <- plot_ly(dataRF, x = ~rf.measure[1,], y = ~rf.measure[2,], name = '3 variable', type = 'scatter', mode = 'lines+markers')
axisNames <- axis_func('Weight', 'Weighted Measure',TRUE)
pRF <- layout(pRF, xaxis = axisNames[[1]], yaxis = axisNames[[2]])
pRF

# ---------------------- Regular scale -----
alaramClassWeight <- 1:21
rf.measure  <- matrix(0,2,length(alaramClassWeight))

for (weight in alaramClassWeight)
{
  w <- ((weight-1)*150)+1000
  print(paste0("w: ",w))
  RF <- createForest_CV_byMeasure(df.train, df.train.tags, "Weighted_Measure", c(0.001,w), 136, 5, 4)
  rf.measure[1,weight] <- w
  rf.measure[2,weight] <- RF[[2]]
}

dataRF <- data.frame(t(rf.measure[]))

pRF <- plot_ly(dataRF, x = ~rf.measure[1,], y = ~rf.measure[2,], name = '3 variable', type = 'scatter', mode = 'lines+markers')
axisNames <- axis_func('Weight', 'Weighted Measure', FALSE)
pRF <- layout(pRF, xaxis = axisNames[[1]], yaxis = axisNames[[2]])
pRF


Camparison45 <- as.data.frame(read.csv("C:/R stuff/ML course/136-5--176-4Comparison.csv"))

pRF <- plot_ly(Camparison45, x = ~Camparison45[,1], y = ~Camparison45[,2], name = '4 variables, 176 trees', type = 'scatter', mode = 'lines+markers')
axisNames <- axis_func('Weight', 'Weighted Measure', FALSE)
pRF <- add_trace(pRF, y = ~Camparison45[,3], name = '5 variables, 136 trees', mode = 'lines+markers')
pRF <- layout(pRF, xaxis = axisNames[[1]], yaxis = axisNames[[2]])
pRF

# ---------------------------- RF Tune parameters - num of trees, num of vars ----------

# B
numtreesSeq <- seq(1,150,15) 
numvarsSeq <- 1:ncol(df.train)
rf.measure  <- matrix(0,length(numtreesSeq),length(numvarsSeq))
varsToTest <- numvarsSeq

for (numVars in varsToTest)
{
  i    <- 1 
  for(numtrees in numtreesSeq)
  {
    #RF <- createRF(df.train, df.train.tags, numtrees, numVars, 0)
    RF <- createForest_CV_byMeasure(df.train, df.train.tags, "Weighted_Measure", 0, numtrees, numVars, 4)
    
    #measures <- Model_Test_Measure(RF, "randomForest", df.test, df.test.tags, FALSE, 10)
    rf.measure[i,numVars] <- RF[[2]]
    i              <- i + 1
  }
}

# Plot results graph
dataRF <- data.frame(numtreesSeq, rf.measure)
pRF <- plot_ly(dataRF, x = ~numtreesSeq, y = ~rf.measure[,1], name = '1 variable', type = 'scatter', mode = 'lines+markers')
pRF <- add_trace(pRF, y = ~rf.measure[,2], name = '2 variables' , mode = 'lines+markers') 
pRF <- add_trace(pRF, y = ~rf.measure[,3], name = '3 variables', mode = 'lines+markers')
pRF <- add_trace(pRF, y = ~rf.measure[,4], name = '4 variables' , mode = 'lines+markers') 
pRF <- add_trace(pRF, y = ~rf.measure[,5], name = '5 variables', mode = 'lines+markers')
pRF <- add_trace(pRF, y = ~rf.measure[,6], name = '6 variables' , mode = 'lines+markers') 
pRF <- add_trace(pRF, y = ~rf.measure[,7], name = '7 variables', mode = 'lines+markers')

pRF <- add_trace(pRF, y = ~rf.measure[,8], name = '8 variables', mode = 'lines+markers')
pRF <- add_trace(pRF, y = ~rf.measure[,9], name = '9 variables', mode = 'lines+markers')
pRF <- add_trace(pRF, y = ~rf.measure[,10], name = '10 variables', mode = 'lines+markers')
pRF <- add_trace(pRF, y = ~rf.measure[,11], name = '11 variables', mode = 'lines+markers')
pRF <- add_trace(pRF, y = ~rf.measure[,12], name = '12 variables', mode = 'lines+markers')

axisNames <- axis_func('Number of Trees', 'Weighted Measure', FALSE)
pRF <- layout(pRF, xaxis = axisNames[[1]], yaxis = axisNames[[2]])
pRF

# ---------------------------- RF Run Test --------------- -------------------
RF <- createRF(df.train, df.train.tags, 50, 11, 0)
Model_Test_Measure(RF, "randomForest", df.test, df.test.tags, TRUE, 10)


RF <- createRF(df.train, df.train.tags, 176, 4, c(0.001,2200))
Model_Test_Measure(RF, "randomForest", df.test, df.test.tags, TRUE, 10)

# Variable Importance Plot
varImpPlot(RF, sort = T,main="Variable Importance", n.var=12)

################## ------------------$$$ NN $$$-----------------------------------------------------------------------------

######### -------------- NN Run Test ---------------

NN <- createNN(df.train, df.train.tags, 15)
rawPredsNN   <- predict(NN, newdata=df.test, type='raw')
Test_Measure_byThreshold(rawPredsNN, df.test.tags, 0.15, TRUE, 10)


#import function from Github
#require(RCurl)
root.url<-'https://gist.githubusercontent.com/fawda123'
raw.fun<-paste(root.url,'5086859/raw/cc1544804d5027d82b70e74b83b3941cd2184354/nnet_plot_fun.r',sep='/')
script<-getURL(raw.fun, ssl.verifypeer = FALSE)
eval(parse(text = script))
##rm('script','raw.fun')
#par(mar=numeric(4),mfrow=c(1,2),family='serif')
train.data <- df.train
train.data.tags <- df.train.tags
#https://beckmw.wordpress.com/2013/11/14/visualizing-neural-networks-in-r-update/
plot.nnet(NN,pos.col='firebrick',neg.col='dimgray',rel.rsc=7,circle.cex=5,cex=1.0, circle.col='sandybrown')


# ------------- NN Tune parameter - num of neurons ----------

numNeuronsSeq <- seq(1,50,2)
nn.measure  <- matrix(0,length(numNeuronsSeq),1)

i    <- 1 
for(numNeurons in numNeuronsSeq)
{
  NN <- createNN_CV_byMeasure(df.train, df.train.tags, "Weighted_Measure", numNeurons, 4)
  nn.measure[i,1] <- NN[[2]]
  i              <- i + 1
}

dataRF <- data.frame(numNeuronsSeq, nn.measure)
pRF <- plot_ly(dataRF, x = ~numNeuronsSeq, y = ~nn.measure, name = 'Threshold 0.5', type = 'scatter', mode = 'lines+markers')
axisNames <- axis_func('Number of Neurons', 'Weighted Measure',FALSE)
pRF <- layout(pRF, xaxis = axisNames[[1]], yaxis = axisNames[[2]])
pRF

# ------------- NN Tune parameter - num of neurons & threshold----------


#thresholds = seq(0.1,0.9,0.1)
thresholds = 0.5

numNeuronsSeq <- seq(1,50,2)
nn.measure  <- matrix(0,length(numNeuronsSeq),length(thresholds))
i    <- 1 
for(numNeurons in numNeuronsSeq)
{
  NN <- createNN_CV_byMeasure_threshold(df.train, df.train.tags, "Weighted_Measure", numNeurons, 4, thresholds)
  nn.measure[i,] <- NN[[2]]
  i              <- i + 1
}

# Plot results graph
dataRF <- data.frame(numNeuronsSeq, nn.measure)
pRF <- plot_ly(dataRF, x = ~numNeuronsSeq, y = ~nn.measure[,3], name = 'Threshold 0.15', type = 'scatter', mode = 'lines+markers')
pRF <- add_trace(pRF, y = ~nn.measure[,2], name = 'Threshold 0.1' , mode = 'lines+markers') 
pRF <- add_trace(pRF, y = ~nn.measure[,3], name = 'Threshold 0.15', mode = 'lines+markers')
pRF <- add_trace(pRF, y = ~nn.measure[,4], name = 'Threshold 0.2' , mode = 'lines+markers') 
pRF <- add_trace(pRF, y = ~nn.measure[,5], name = 'Threshold 0.25', mode = 'lines+markers')
pRF <- add_trace(pRF, y = ~nn.measure[,6], name = 'Threshold 0.3' , mode = 'lines+markers') 
pRF <- add_trace(pRF, y = ~nn.measure[,7], name = 'Threshold 0.35', mode = 'lines+markers')
pRF <- add_trace(pRF, y = ~nn.measure[,8], name = 'Threshold 0.4', mode = 'lines+markers')
pRF <- add_trace(pRF, y = ~nn.measure[,9], name = 'Threshold 0.45', mode = 'lines+markers')
pRF <- add_trace(pRF, y = ~nn.measure[,10], name = 'Threshold 0.5', mode = 'lines+markers')
pRF <- add_trace(pRF, y = ~nn.measure[,11], name = 'Threshold 0.55', mode = 'lines+markers')
pRF <- add_trace(pRF, y = ~nn.measure[,12], name = 'Threshold 0.6', mode = 'lines+markers')
pRF <- add_trace(pRF, y = ~nn.measure[,13], name = 'Threshold 0.65', mode = 'lines+markers')
pRF <- add_trace(pRF, y = ~nn.measure[,14], name = 'Threshold 0.7', mode = 'lines+markers')
pRF <- add_trace(pRF, y = ~nn.measure[,15], name = 'Threshold 0.75', mode = 'lines+markers')
pRF <- add_trace(pRF, y = ~nn.measure[,16], name = 'Threshold 0.8' , mode = 'lines+markers') 
pRF <- add_trace(pRF, y = ~nn.measure[,17], name = 'Threshold 0.85', mode = 'lines+markers')
pRF <- add_trace(pRF, y = ~nn.measure[,18], name = 'Threshold 0.9' , mode = 'lines+markers') 
pRF <- add_trace(pRF, y = ~nn.measure[,19], name = 'Threshold 0.95', mode = 'lines+markers')
axisNames <- axis_func('Number of Neurons', 'Weighted Measure',FALSE)
pRF <- layout(pRF, xaxis = axisNames[[1]], yaxis = axisNames[[2]])
pRF

#pRF0_50 <- pRF





















##################### ------------------- Temp -------------

NN <- createNN(df.train, df.train.tags, 10)

#####################------------------- NN loop -------------------#########################

numNeuronsSeq <- seq(1,50,1)
#nn.models  <- matrix[0,length(numNeuronsSeq),1]
nn.accuracy  <- matrix(0,length(numNeuronsSeq),1)

i    <- 1 
for(numNeurons in numNeuronsSeq)
{
  NN <- createNN(df.train, df.train.tags, df.validation, df.validation.tags, numNeurons)
  #    nn.models[[i,1]]        <- NN[[1]]
  nn.accuracy[i,1]        <- NN[[2]]
  i              <- i + 1
}


dataNN <- data.frame(numNeuronsSeq, nn.accuracy)

pNN <- plot_ly(dataNN, x = ~numNeuronsSeq, y = ~nn.accuracy, name = 'Number of Neurons', type = 'scatter', mode = 'lines+markers')
axisNames <- axis_func('Number of Neurons', 'Accuracy rate')
pNN <- layout(pNN, xaxis = axisNames[[1]], yaxis = axisNames[[2]])
pNN

#check min/max accuracy
min <- nn.accuracy[which.min(nn.accuracy)]
max <- nn.accuracy[which.max(nn.accuracy)]

######### Run test
#NN <- createNN(df.train, df.train.tags, df.test, df.test.tags, 4)
nn             <- nnet(x=df.train, y=class.ind(df.train.tags), size=4, linout=FALSE, softmax=T)
nn.predict.valid   <- factor(predict(nn, newdata=df.test, type='class'))
nn.accuracy <-  (sum(nn.predict.valid==df.test.tags))/nrow(df.test)
nn.accuracy
# Create Confusion Matrix

predict <- unname(nn.predict.valid, force = FALSE)
conf <- confusionMatrix(data=factor(predict), reference=factor(df.test.tags), positive="1")
conf

plot.nnet(nn,pos.col='firebrick',neg.col='dimgray',rel.rsc=7,circle.cex=5,cex=1.0, circle.col='sandybrown')


#import the function from Github
#source_url('https://gist.githubusercontent.com/Peque/41a9e20d6687f2f3108d/raw/85e14f3a292e126f1454864427e3a189c2fe33f3/nnet_plot_update.r')

#plot each model
#pdf('./nn-example.pdf', width = 7, height = 7)
#plotnet<-plot.nnet(nn, wts.only=T)
#plot.nnet(nn,pos.col='darkgreen',neg.col='darkblue',alpha.val=0.7,rel.rsc=15,circle.cex=10,cex=1.4, circle.col='brown')
#dev.off()
#par(mar=numeric(4),family='serif')


#import function from Github
#require(RCurl)

root.url<-'https://gist.githubusercontent.com/fawda123'
raw.fun<-paste(root.url,'5086859/raw/cc1544804d5027d82b70e74b83b3941cd2184354/nnet_plot_fun.r',sep='/')
script<-getURL(raw.fun, ssl.verifypeer = FALSE)
eval(parse(text = script))
##rm('script','raw.fun')

#par(mar=numeric(4),mfrow=c(1,2),family='serif')
plot(nn,nid=F)
plot(nn)

#https://beckmw.wordpress.com/2013/11/14/visualizing-neural-networks-in-r-update/
plot.nnet(nn,pos.col='firebrick',neg.col='dimgray',rel.rsc=7,circle.cex=5,cex=1.0, circle.col='sandybrown')

unname(nn.predict.valid, force = FALSE)

# Get data for ROC curve
nn.predict   <- unname(predict(nn, newdata=df.test), force = FALSE)
perf.obj <- prediction(predictions=as.data.frame(nn.predict), labels=as.data.frame(df.test.tags))
roc.obj <- performance(perf.obj, measure="tpr", x.measure="fpr")
plot(roc.obj, main="Cross-Sell - ROC Curves", xlab="1 - Specificity: False Positive Rate", ylab="Sensitivity: True Positive Rate", col="blue")
abline(0,1,col="grey")






#check min/max accuracy
min <- rf.accuracy[which.min(rf.accuracy)]
max <- rf.accuracy[which.max(rf.accuracy)]

RF <- createRF(df.train, df.train.tags, df.test, df.test.tags, 109, 2)

importance(RF[[1]])

# Variable Importance Plot
varImpPlot(RF[[1]],
           sort = T,
           main="Variable Importance",
           n.var=12)

# Create Confusion Matrix
conf <- confusionMatrix(data=factor(RF[[3]]), reference=factor(df.test.tags), positive="1")
