#Installation of relevant Packages
install.packages("ROCR")
install.packages("e1071")
install.packages("rattle")
install.packages("rpart")
install.packages("reshape2")

#Define Word Directory and read the CSV
setwd("C:\\")
german.credit<-read.csv("German.Credit.csv",header=TRUE, sep = ",")
attach(german.credit)
set.seed(1017) #to start every checking from the same place

#Libraries in use
library(ROCR, warn.conflicts = FALSE, quietly = TRUE, verbose = FALSE)
library(e1071,warn.conflicts = FALSE, quietly= TRUE, verbose = FALSE)
library(rpart,warn.conflicts = FALSE, quietly= TRUE, verbose = FALSE)
library(rattle, warn.conflicts = FALSE, quietly = TRUE, verbose = FALSE)
library(reshape2)

#Define variables
frac_train=0.8 #Divide factor for train and test sets
L_GB=5
L_BG=1
#Loop's preferences
nfolds<-5 #How much time I'm doing the cross validation.
case.folds<-rep(1:nfolds,length.out=nrow(german.credit))
#divide the case as evenly as possible
case.folds<-sample(case.folds) #Randomly permute the order
aucglmvec<-c(0,0,0,0,0)
lossglmvec<-c(0,0,0,0,0)
aucnbvec<-c(0,0,0,0,0)
lossnbvec<-c(0,0,0,0,0)
auctreevec<-c(0,0,0,0,0)
losstreevec<-c(0,0,0,0,0)
count<-1

for(i in 1:nfolds){
  indx<-which(case.folds !=i)
  #indx = sample(1:nrow(german.credit),size=frac_train*nrow(german.credit))
  #Define the sets - train and test for this iteration
  traindata<-german.credit[indx,]
  testdata<-german.credit[-indx,]
  #3 Models
  #Linear Regression
  #ROC Curves+AUC
  glm.fit=glm(class~.,data=traindata,family=binomial)
  labelglm = ifelse(testdata$class == "good", 1, 0)
  glm.prob = predict(glm.fit,newdata = testdata, type="response")
  pred.glm<-prediction(glm.prob,labelglm)
  ROC.glm<-performance(pred.glm,"tpr","fpr")
  auc1 = performance(pred.glm, "auc")
  auc1 = auc1@y.values[[1]]
  auc1.glm = round( auc1 , digits=3)
  aucglmvec[count]<-auc1.glm
  #Calculate the loss
  labelglm.trn = ifelse(traindata$class == "good", 1, 0)#Calculate the threshold
  glm.prob.trn <- predict(glm.fit,newdata = traindata, type="response")
  pred.trn.glm <- prediction(glm.prob.trn, labelglm.trn)
  loss1<-performance(pred.trn.glm , "cost", cost.fp=L_GB,cost.fn=L_BG)
  opt_th1 = loss1@x.values[[1]][ which(loss1@y.values[[1]] == min(loss1@y.values[[1]]))]
  pred1 = rep("bad", nrow(testdata))#Build the confusion matrix for the tests data using the threshold found above
  pred1[glm.prob > opt_th1] = "good"
  conf_mat1 = table(pred1,testdata$class)
  loss1.glm = L_GB*conf_mat1[2,1]+L_BG*conf_mat1[1,2]#Calculate the total misclassification loss
  lossglmvec[count]<-loss1.glm
  #Naive Bayes
  #ROC Curves+AUC
  nb.fit<-naiveBayes(class~.,traindata)
  labelnb = ifelse(testdata$class == "good", 1, 0)
  nb.prob <- predict(nb.fit, testdata, type="raw")
  nb.prob <- as.data.frame(nb.prob)[2]
  pred.nb <- prediction(nb.prob,labelnb)
  ROC.nb<-performance(pred.nb, "tpr", "fpr")
  auc2 = performance(pred.nb, "auc")
  auc2 = auc2@y.values[[1]]
  auc2.nb = round( auc2 , digits=3)
  aucnbvec[count]<-auc2.nb
  #Calculate the loss
  labelnb.trn = ifelse(traindata$class == "good", 1, 0)
  nb.prob.trn <- predict(nb.fit,traindata, type="raw")[,2]
  pred.trn.nb <- prediction(nb.prob.trn, labelnb.trn)
  loss2<-performance(pred.trn.nb , "cost", cost.fp=L_GB,cost.fn=L_BG)
  opt_th2 = loss2@x.values[[1]][ which(loss2@y.values[[1]] == min(loss2@y.values[[1]]))]
  pred2 = rep("bad", nrow(testdata))#Build the confusion matrix for the tests data using the threshold found above
  pred2[nb.prob > opt_th2] = "good"
  conf_mat2 = table(pred2,testdata$class)
  loss2.nb = L_GB*conf_mat2[2,1]+L_BG*conf_mat2[1,2]#Calculate the total misclassification loss
  lossnbvec[count]<-loss2.nb
  #Recursive partioning trees
  #ROC Curves+AUC
  tree.fit<-rpart(class~.,data=traindata,control = rpart.control(minsplit = 20,cp=0,maxdepth = 5))
  #labeltree = ifelse(testdata$class == "good", 1, 0)
  #tree.class<- predict(tree.fit,type = 'class',testdata)
  tree.prob <- predict(tree.fit, type = 'prob',testdata)[,2]
  pred.tree <- prediction(tree.prob, testdata$class)
  ROC.tree<-performance(pred.tree, "tpr", "fpr")
  auc3 = performance(pred.tree, "auc")
  auc3 = auc3@y.values[[1]]
  auc3.tree = round( auc3 , digits=3)
  auctreevec[count]<-auc3.tree
  #Calculate the loss
  labeltree.trn =  ifelse(traindata$class == "good", 1, 0)
  tree.prob.trn<-predict(tree.fit,type='prob',traindata)[,2]
  pred.trn.tree<-prediction(tree.prob.trn, labeltree.trn)
  loss3<-performance(pred.trn.tree , "cost", cost.fp=L_GB,cost.fn=L_BG)
  opt_th3 = loss3@x.values[[1]][ which(loss3@y.values[[1]] == min(loss3@y.values[[1]]))]
  pred3 = rep("bad", nrow(testdata))#Build the confusion matrix for the tests data using the threshold found above
  pred3[tree.prob > opt_th3] = "good"
  conf_mat3 = table(pred3,testdata$class)
  loss3.tree = L_GB*conf_mat3[2,1]+L_BG*conf_mat3[1,2]#Calculate the total misclassification loss
  losstreevec[count]<-loss3.tree
  ########performance summary - Plot#################
  #Plot Drawing
  plot(ROC.glm, col='green',lty=1,lwd=2, main='Reciver Operator Characteristic (ROC) Curve')
  plot(ROC.nb, col='red',add=TRUE,lty=1,lwd=2)
  plot(ROC.tree, col='blue',add=TRUE,lty=1,lwd=2)
  abline(a=0,b=1,lty=2, col='black')
  legend("bottomright", c('GLM','NB','TREE','RNDM'),col=c('green','red','blue','black'),lty=c(1,1,1,2), lwd=c(2,2,2,1))
  
  count<-count+1
}
#BoxPlot Drawing
#AUC
boxplotdataauc<-data.frame(GLM=aucglmvec,NB=aucnbvec,TREE=auctreevec)
meltauc <- melt(boxplotdataauc)
plot(value~variable,data=meltauc, main='Total AUC Boxplot', xlab="classifier", ylab="AUC")
#Loss
boxplotdataloss<-data.frame(GLM=lossglmvec,NB=lossnbvec,TREE=losstreevec)
meltloss <- melt(boxplotdataloss)
plot(value~variable,data=meltloss,main='Total LOSS Boxplot', xlab="classifier", ylab="LOSS")
#Table of results
results <- matrix(c(aucglmvec[1],aucnbvec[1],auctreevec[1],lossglmvec[1],lossnbvec[1],losstreevec[1],aucglmvec[2],aucnbvec[2],auctreevec[2],lossglmvec[2],lossnbvec[2],losstreevec[2],aucglmvec[3],aucnbvec[3],auctreevec[3],lossglmvec[3],lossnbvec[3],losstreevec[3],aucglmvec[4],aucnbvec[4],auctreevec[4],lossglmvec[4],lossnbvec[4],losstreevec[4],aucglmvec[5],aucnbvec[5],auctreevec[5],lossglmvec[5],lossnbvec[5],losstreevec[5]),ncol=10,byrow=FALSE)
colnames(results) <- c("AUC1","LOSS1","AUC2","LOSS2","AUC3","LOSS3","AUC4","LOSS4","AUC5","LOSS5")
rownames(results) <- c("GLM","NB","TREE")
results <- as.table(results)
results
